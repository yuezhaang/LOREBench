# Injected from runtests.jl
using Distributions
using PDMats # test dependencies
using Test
using Distributed
using Random
using SpecialFunctions
using StatsBase
using LinearAlgebra

import JSON
import ForwardDiff

const tests = [
    "aqua",
    "univariate/continuous/loguniform",
    "univariate/continuous/arcsine",
    "univariate/discrete/dirac",
    "truncate",
    "truncated/normal",
    "truncated/exponential",
    "truncated/uniform",
    "truncated/discrete_uniform",
    "censored",
    "univariate/continuous/normal",
    "univariate/continuous/normalcanon",
    "univariate/continuous/laplace",
    "univariate/continuous/cauchy",
    "univariate/continuous/uniform",
    "univariate/continuous/lognormal",
    "multivariate/mvnormal",
    "multivariate/mvlogitnormal",
    "multivariate/mvlognormal",
    "types", # extra file compared to /src
    "utils",
    "samplers",
    "univariate/discrete/categorical",
    "univariates",
    "univariate/continuous", # extra file compared to /src
    "edgecases", # extra file compared to /src
    "fit", # extra file compared to /src
    "multivariate/multinomial",
    "univariate/discrete/binomial",
    "univariate/discrete/betabinomial",
    "univariate/discrete/poissonbinomial",
    "multivariate/dirichlet",
    "multivariate/dirichletmultinomial",
    "univariate/continuous/logitnormal",
    "multivariate/mvtdist",
    "univariate/continuous/kolmogorov",
    "edgeworth",
    "matrixreshaped", # extra file compared to /src
    "matrixvariates",
    "cholesky/lkjcholesky",
    "multivariate/vonmisesfisher",
    "conversion",
    "convolution",
    "mixture", # extra file compared to /src
    "gradlogpdf", # extra file compared to /src
    "univariate/continuous/noncentralt",
    "univariate/locationscale",
    "quantile_newton", # extra file compared to /src
    "univariate/continuous/semicircle",
    "qq",
    "univariate/continuous/pgeneralizedgaussian",
    "product",
    "namedtuple/productnamedtuple",
    "univariate/discrete/discretenonparametric",
    "univariate/continuous/chernoff",
    "univariate_bounds", # extra file compared to /src
    "univariate/discrete/negativebinomial",
    "univariate/discrete/geometric",
    "univariate/discrete/bernoulli",
    "univariate/discrete/poisson",
    "univariate/discrete/soliton",
    "univariate/continuous/skewnormal",
    "univariate/continuous/chi",
    "univariate/continuous/chisq",
    "univariate/continuous/erlang",
    "univariate/continuous/exponential",
    "univariate/continuous/gamma",
    "univariate/continuous/gumbel",
    "univariate/continuous/lindley",
    "univariate/continuous/logistic",
    "univariate/continuous/johnsonsu",
    "univariate/continuous/noncentralchisq",
    "univariate/continuous/weibull",
    "pdfnorm",
    "univariate/continuous/pareto",
    "univariate/continuous/rician",
    "functionals",
    "density_interface",
    "reshaped",
    "univariate/continuous/skewedexponentialpower",
    "univariate/discrete/discreteuniform",
    "univariate/continuous/tdist",
    "univariate/orderstatistic",
    "multivariate/jointorderstatistics",
    "multivariate/product",
    "eachvariate",
    "univariate/continuous/triangular",
    "statsapi",
    "univariate/continuous/inversegaussian",

    ### missing files compared to /src:
    # "common",
    # "estimators",
    # "genericfit",
    # "matrix/inversewishart",
    # "matrix/lkj",
    # "matrix/matrixbeta",
    # "matrix/matrixfdist",
    # "matrix/matrixnormal",
    # "matrix/matrixtdist",
    # "matrix/wishart",
    # "mixtures/mixturemodel",
    # "mixtures/unigmm",
    # "multivariate/mvnormalcanon",
    # "quantilealgs",
    # "samplers/aliastable",
    # "samplers/binomial",
    # "samplers/categorical",
    # "samplers/discretenonparametric",
    # "samplers/exponential",
    # "samplers/gamma",
    # "samplers/multinomial",
    # "samplers/obsoleted",
    # "samplers/poisson",
    # "samplers/poissonbinomial",
    # "samplers/vonmises",
    # "samplers/vonmisesfisher",
    # "show",
    # "truncated/loguniform",
    # "univariate/continuous/beta",
    # "univariate/continuous/beta",
    # "univariate/continuous/betaprime",
    # "univariate/continuous/biweight",
    # "univariate/continuous/cosine",
    # "univariate/continuous/epanechnikov",
    # "univariate/continuous/fdist",
    # "univariate/continuous/frechet",
    # "univariate/continuous/generalizedextremevalue",
    # "univariate/continuous/generalizedpareto",
    # "univariate/continuous/inversegamma",
    # "univariate/continuous/ksdist",
    # "univariate/continuous/ksonesided",
    # "univariate/continuous/levy",
    # "univariate/continuous/noncentralbeta",
    # "univariate/continuous/noncentralf",
    # "univariate/continuous/normalinversegaussian",
    # "univariate/continuous/rayleigh",
    # "univariate/continuous/studentizedrange",
    # "univariate/continuous/symtriangular",
    # "univariate/continuous/tdist",
    # "univariate/continuous/triweight",
    # "univariate/continuous/noncentralf",
    # "univariate/discrete/geometric",
    # "univariate/discrete/hypergeometric",
    # "univariate/discrete/noncentralhypergeometric",
    # "univariate/discrete/poisson",
    # "univariate/discrete/skellam",

    ### file is present but was not included in list
    # "multivariate_stats", # extra file compared to /src
    # "univariate/continuous/vonmises",
]

printstyled("Running tests:\n", color=:blue)

Random.seed!(345679)

# to reduce redundancy, we might break this file down into separate `$t * "_utils.jl"` files
include("testutils.jl")

# TODO: Remove when `MatrixReshaped` is removed
using Distributions, Test, Random, LinearAlgebra

rng = MersenneTwister(123456)

function test_matrixreshaped(rng, d1, sizes)
    @testset "MatrixReshaped $(nameof(typeof(d1))) tests" begin
        x1 = rand(rng, d1)
        d1s = [@test_deprecated(MatrixReshaped(d1, s...)) for s in sizes]

        @testset "MatrixReshaped constructor" begin
            for d in d1s
                @test d isa MatrixReshaped
            end
        end
        @testset "MatrixReshaped constructor errors" begin
            @test_deprecated(@test_throws ArgumentError MatrixReshaped(d1, length(d1), 2))
            @test_deprecated(@test_throws ArgumentError MatrixReshaped(d1, length(d1)))
            @test_deprecated(@test_throws ArgumentError MatrixReshaped(d1, -length(d1), -1))
        end
        @testset "MatrixReshaped size" begin
            for (d, s) in zip(d1s[1:end-1], sizes[1:end-1])
                @test size(d) == s
            end
        end
        @testset "MatrixReshaped length" begin
            for d in d1s
                @test length(d) == length(d1)
            end
        end
        @testset "MatrixReshaped rank" begin
            for (d, s) in zip(d1s, sizes)
                @test rank(d) == minimum(s)
            end
        end
        @testset "MatrixReshaped insupport" begin
            for (i, d) in enumerate(d1s[1:end-1])
                for (j, s) in enumerate(sizes[1:end-1])
                    @test (i == j) ⊻ !insupport(d, reshape(x1, s))
                end
            end
        end
        @testset "MatrixReshaped mean" begin
            for (d, s) in zip(d1s[1:end-1], sizes[1:end-1])
                @test mean(d) == reshape(mean(d1), s)
            end
        end
        @testset "MatrixReshaped mode" begin
            for (d, s) in zip(d1s[1:end-1], sizes[1:end-1])
                @test mode(d) == reshape(mode(d1), s)
            end
        end
        @testset "MatrixReshaped covariance" begin
            for (d, (n, p)) in zip(d1s[1:end-1], sizes[1:end-1])
                @test cov(d) == cov(d1)
                @test cov(d, Val(false)) == reshape(cov(d1), n, p, n, p)
            end
        end
        @testset "MatrixReshaped variance" begin
            for (d, s) in zip(d1s[1:end-1], sizes[1:end-1])
                @test var(d) == reshape(var(d1), s)
            end
        end
        @testset "MatrixReshaped params" begin
            for (d, s) in zip(d1s[1:end-1], sizes[1:end-1])
                @test params(d) == (d1, s)
            end
        end
        @testset "MatrixReshaped partype" begin
            for d in d1s
                @test partype(d) === partype(d1)
            end
        end
        @testset "MatrixReshaped eltype" begin
            for d in d1s
                @test eltype(d) === eltype(d1)
            end
        end
        @testset "MatrixReshaped logpdf" begin
            for (d, s) in zip(d1s[1:end-1], sizes[1:end-1])
                x = reshape(x1, s)
                @test logpdf(d, x) == logpdf(d1, x1)
            end
        end
        @testset "MatrixReshaped rand" begin
            for d in d1s
                x = rand(rng, d)
                @test insupport(d, x)
                @test insupport(d1, vec(x))
                @test logpdf(d, x) == logpdf(d1, vec(x))
            end
        end
        @testset "MatrixReshaped vec" begin
            for d in d1s
                @test vec(d) === d1
            end
        end
    end
end

# Note: In contrast to `@deprecate`, `@deprecate_binding` can't be tested with `@test_deprecated`
# Ref: https://github.com/JuliaLang/julia/issues/38780
@testset "matrixreshaped.jl" begin
    @testset "MvNormal" begin
        σ = rand(rng, 16, 16)
        μ = rand(rng, 16)
        d1 = MvNormal(μ, σ * σ')
        sizes = [(4, 4), (8, 2), (2, 8), (1, 16), (16, 1), (4,)]
        redirect_stderr(devnull) do
            test_matrixreshaped(rng, d1, sizes)
        end
    end

    # Dirichlet
    @testset "Dirichlet" begin
        α = rand(rng, 36) .+ 1 # mode is only defined if all alpha > 1
        d1 = Dirichlet(α)
        sizes = [(6, 6), (4, 9), (9, 4), (3, 12), (12, 3), (1, 36), (36, 1), (6,)]
        redirect_stderr(devnull) do
            test_matrixreshaped(rng, d1, sizes)
        end
    end
end

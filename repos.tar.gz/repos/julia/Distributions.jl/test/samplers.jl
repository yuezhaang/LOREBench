# Injected from runtests.jl
using Distributions
using PDMats # test dependencies
using Test
using Distributed
using Random
using SpecialFunctions
using StatsBase
using LinearAlgebra

import JSON
import ForwardDiff

const tests = [
    "aqua",
    "univariate/continuous/loguniform",
    "univariate/continuous/arcsine",
    "univariate/discrete/dirac",
    "truncate",
    "truncated/normal",
    "truncated/exponential",
    "truncated/uniform",
    "truncated/discrete_uniform",
    "censored",
    "univariate/continuous/normal",
    "univariate/continuous/normalcanon",
    "univariate/continuous/laplace",
    "univariate/continuous/cauchy",
    "univariate/continuous/uniform",
    "univariate/continuous/lognormal",
    "multivariate/mvnormal",
    "multivariate/mvlogitnormal",
    "multivariate/mvlognormal",
    "types", # extra file compared to /src
    "utils",
    "samplers",
    "univariate/discrete/categorical",
    "univariates",
    "univariate/continuous", # extra file compared to /src
    "edgecases", # extra file compared to /src
    "fit", # extra file compared to /src
    "multivariate/multinomial",
    "univariate/discrete/binomial",
    "univariate/discrete/betabinomial",
    "univariate/discrete/poissonbinomial",
    "multivariate/dirichlet",
    "multivariate/dirichletmultinomial",
    "univariate/continuous/logitnormal",
    "multivariate/mvtdist",
    "univariate/continuous/kolmogorov",
    "edgeworth",
    "matrixreshaped", # extra file compared to /src
    "matrixvariates",
    "cholesky/lkjcholesky",
    "multivariate/vonmisesfisher",
    "conversion",
    "convolution",
    "mixture", # extra file compared to /src
    "gradlogpdf", # extra file compared to /src
    "univariate/continuous/noncentralt",
    "univariate/locationscale",
    "quantile_newton", # extra file compared to /src
    "univariate/continuous/semicircle",
    "qq",
    "univariate/continuous/pgeneralizedgaussian",
    "product",
    "namedtuple/productnamedtuple",
    "univariate/discrete/discretenonparametric",
    "univariate/continuous/chernoff",
    "univariate_bounds", # extra file compared to /src
    "univariate/discrete/negativebinomial",
    "univariate/discrete/geometric",
    "univariate/discrete/bernoulli",
    "univariate/discrete/poisson",
    "univariate/discrete/soliton",
    "univariate/continuous/skewnormal",
    "univariate/continuous/chi",
    "univariate/continuous/chisq",
    "univariate/continuous/erlang",
    "univariate/continuous/exponential",
    "univariate/continuous/gamma",
    "univariate/continuous/gumbel",
    "univariate/continuous/lindley",
    "univariate/continuous/logistic",
    "univariate/continuous/johnsonsu",
    "univariate/continuous/noncentralchisq",
    "univariate/continuous/weibull",
    "pdfnorm",
    "univariate/continuous/pareto",
    "univariate/continuous/rician",
    "functionals",
    "density_interface",
    "reshaped",
    "univariate/continuous/skewedexponentialpower",
    "univariate/discrete/discreteuniform",
    "univariate/continuous/tdist",
    "univariate/orderstatistic",
    "multivariate/jointorderstatistics",
    "multivariate/product",
    "eachvariate",
    "univariate/continuous/triangular",
    "statsapi",
    "univariate/continuous/inversegaussian",

    ### missing files compared to /src:
    # "common",
    # "estimators",
    # "genericfit",
    # "matrix/inversewishart",
    # "matrix/lkj",
    # "matrix/matrixbeta",
    # "matrix/matrixfdist",
    # "matrix/matrixnormal",
    # "matrix/matrixtdist",
    # "matrix/wishart",
    # "mixtures/mixturemodel",
    # "mixtures/unigmm",
    # "multivariate/mvnormalcanon",
    # "quantilealgs",
    # "samplers/aliastable",
    # "samplers/binomial",
    # "samplers/categorical",
    # "samplers/discretenonparametric",
    # "samplers/exponential",
    # "samplers/gamma",
    # "samplers/multinomial",
    # "samplers/obsoleted",
    # "samplers/poisson",
    # "samplers/poissonbinomial",
    # "samplers/vonmises",
    # "samplers/vonmisesfisher",
    # "show",
    # "truncated/loguniform",
    # "univariate/continuous/beta",
    # "univariate/continuous/beta",
    # "univariate/continuous/betaprime",
    # "univariate/continuous/biweight",
    # "univariate/continuous/cosine",
    # "univariate/continuous/epanechnikov",
    # "univariate/continuous/fdist",
    # "univariate/continuous/frechet",
    # "univariate/continuous/generalizedextremevalue",
    # "univariate/continuous/generalizedpareto",
    # "univariate/continuous/inversegamma",
    # "univariate/continuous/ksdist",
    # "univariate/continuous/ksonesided",
    # "univariate/continuous/levy",
    # "univariate/continuous/noncentralbeta",
    # "univariate/continuous/noncentralf",
    # "univariate/continuous/normalinversegaussian",
    # "univariate/continuous/rayleigh",
    # "univariate/continuous/studentizedrange",
    # "univariate/continuous/symtriangular",
    # "univariate/continuous/tdist",
    # "univariate/continuous/triweight",
    # "univariate/continuous/noncentralf",
    # "univariate/discrete/geometric",
    # "univariate/discrete/hypergeometric",
    # "univariate/discrete/noncentralhypergeometric",
    # "univariate/discrete/poisson",
    # "univariate/discrete/skellam",

    ### file is present but was not included in list
    # "multivariate_stats", # extra file compared to /src
    # "univariate/continuous/vonmises",
]

printstyled("Running tests:\n", color=:blue)

Random.seed!(345679)

# to reduce redundancy, we might break this file down into separate `$t * "_utils.jl"` files
include("testutils.jl")

# Testing of samplers

using Distributions, Random, StatsBase, Test

import Distributions:
    CategoricalDirectSampler,
    AliasTable,
    BinomialGeomSampler,
    BinomialTPESampler,
    BinomialPolySampler,
    BinomialAliasSampler,
    PoissonADSampler,
    PoissonCountSampler,
    ExponentialSampler,
    GammaGDSampler,
    GammaGSSampler,
    GammaMTSampler,
    GammaIPSampler,
    PoissBinAliasSampler

@testset "samplers" begin
    n_tsamples = 10^6

    ## Categorical samplers

    @test_throws ArgumentError CategoricalDirectSampler(Float64[])
    @test_throws ArgumentError AliasTable(Float64[])

    rng = MersenneTwister(123)
    @testset "Categorical: $S" for S in [CategoricalDirectSampler, AliasTable]
        @testset "p=$p" for p in Any[[1.0], [0.3, 0.7], [0.2, 0.3, 0.4, 0.1]]
            test_samples(S(p), Categorical(p), n_tsamples)
            test_samples(S(p), Categorical(p), n_tsamples, rng=rng)
            @test ncategories(S(p)) == length(p)
        end
    end

    @test string(AliasTable(Float16[1,2,3])) == "AliasTable with 3 entries"

    ## Binomial samplers

    binomparams = [(0, 0.4), (0, 0.6), (5, 0.0), (5, 1.0),
                   (1, 0.2), (1, 0.8), (3, 0.4), (4, 0.6),
                   (40, 0.5), (100, 0.4), (300, 0.6)]

    @testset "Binomial: $S" for (S, paramlst) in [
            (BinomialGeomSampler, [(0, 0.4), (0, 0.6), (5, 0.0), (5, 1.0), (1, 0.2), (1, 0.8), (3, 0.4), (4, 0.6)]),
            (BinomialTPESampler, [(40, 0.5), (100, 0.4), (300, 0.6)]),
            (BinomialPolySampler, binomparams),
            (BinomialAliasSampler, binomparams) ]
        @testset "pa=$pa" for pa in paramlst
            n, p = pa
            test_samples(S(n, p), Binomial(n, p), n_tsamples)
            test_samples(S(n, p), Binomial(n, p), n_tsamples, rng=rng)
        end
    end

    ## Poisson samplers

    @testset "Poisson: $S" for
        (S, paramlst) in [
            (PoissonCountSampler, [0.2, 0.5, 1.0, 2.0, 5.0, 10.0, 15.0, 20.0, 30.0]),
            (PoissonADSampler, [10.0, 15.0, 20.0, 30.0])]
        @testset "μ=$μ" for μ in paramlst
            test_samples(S(μ), Poisson(μ), n_tsamples)
            test_samples(S(μ), Poisson(μ), n_tsamples, rng=rng)
        end
    end

    ## Poisson Binomial sampler
    @testset "Poisson-Binomial: $S" for S in (PoissBinAliasSampler,)
        @testset "p=$p" for p in (fill(0.2, 30), range(0.1, stop = .99, length = 30), [fill(0.1, 10); fill(0.9, 10)])
            d = PoissonBinomial(p)
            test_samples(S(d), d, n_tsamples)
            test_samples(S(d), d, n_tsamples, rng=rng)
        end
    end


    ## Exponential samplers

    @testset "Exponential: $S" for S in [ExponentialSampler]
        @testset "scale=$scale" for scale in [1.0, 2.0, 3.0]
            test_samples(S(scale), Exponential(scale), n_tsamples)
            test_samples(S(scale), Exponential(scale), n_tsamples, rng=rng)
        end
    end


    ## Gamma samplers
    @testset "Gamma (shape >= 1): $S" for S in [GammaGDSampler, GammaMTSampler]
        @testset "d=$d" for d in [Gamma(1.0, 1.0), Gamma(2.0, 1.0), Gamma(3.0, 1.0),
              Gamma(1.0, 2.0), Gamma(3.0, 2.0), Gamma(100.0, 2.0)]
            test_samples(S(d), d, n_tsamples)
            test_samples(S(d), d, n_tsamples, rng=rng)
        end
    end

    @testset "Gamma (shape < 1): $S" for S in [GammaGSSampler, GammaIPSampler]
        @testset "d=$d" for d in [Gamma(0.1,1.0),Gamma(0.9,1.0)]
            test_samples(S(d), d, n_tsamples)
            test_samples(S(d), d, n_tsamples, rng=rng)
        end
    end

    @testset "GammaIPSampler" begin
        @testset "d=$d" for d in [Gamma(0.1, 1.0), Gamma(0.9, 1.0)]
            s = sampler(d)
            @test s isa GammaIPSampler{<:GammaMTSampler}
            @test s.s isa GammaMTSampler
            test_samples(s, d, n_tsamples)
            test_samples(s, d, n_tsamples, rng=rng)

            s = @inferred(GammaIPSampler(d, GammaMTSampler))
            @test s isa GammaIPSampler{<:GammaMTSampler}
            @test s.s isa GammaMTSampler
            test_samples(s, d, n_tsamples)
            test_samples(s, d, n_tsamples, rng=rng)

            s = @inferred(GammaIPSampler(d, GammaGDSampler))
            @test s isa GammaIPSampler{<:GammaGDSampler}
            @test s.s isa GammaGDSampler
            test_samples(s, d, n_tsamples)
            test_samples(s, d, n_tsamples, rng=rng)
        end
    end

    @testset "Random.Sampler" begin
        for dist in (
            Binomial(5, 0.3),
            Exponential(2.0),
            Gamma(0.1, 1.0),
            Gamma(2.0, 1.0),
            MatrixNormal(3, 4),
            MvNormal(zeros(3), I),
            Normal(1.5, 2.0),
            Poisson(0.5),
        )
            @test Random.Sampler(rng, dist, Val(1)) == dist
            @test Random.Sampler(rng, dist) == sampler(dist)
        end
    end
end

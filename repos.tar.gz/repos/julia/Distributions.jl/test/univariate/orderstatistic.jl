# Injected from runtests.jl
using Distributions
using PDMats # test dependencies
using Test
using Distributed
using Random
using SpecialFunctions
using StatsBase
using LinearAlgebra

import JSON
import ForwardDiff

const tests = [
    "aqua",
    "univariate/continuous/loguniform",
    "univariate/continuous/arcsine",
    "univariate/discrete/dirac",
    "truncate",
    "truncated/normal",
    "truncated/exponential",
    "truncated/uniform",
    "truncated/discrete_uniform",
    "censored",
    "univariate/continuous/normal",
    "univariate/continuous/normalcanon",
    "univariate/continuous/laplace",
    "univariate/continuous/cauchy",
    "univariate/continuous/uniform",
    "univariate/continuous/lognormal",
    "multivariate/mvnormal",
    "multivariate/mvlogitnormal",
    "multivariate/mvlognormal",
    "types", # extra file compared to /src
    "utils",
    "samplers",
    "univariate/discrete/categorical",
    "univariates",
    "univariate/continuous", # extra file compared to /src
    "edgecases", # extra file compared to /src
    "fit", # extra file compared to /src
    "multivariate/multinomial",
    "univariate/discrete/binomial",
    "univariate/discrete/betabinomial",
    "univariate/discrete/poissonbinomial",
    "multivariate/dirichlet",
    "multivariate/dirichletmultinomial",
    "univariate/continuous/logitnormal",
    "multivariate/mvtdist",
    "univariate/continuous/kolmogorov",
    "edgeworth",
    "matrixreshaped", # extra file compared to /src
    "matrixvariates",
    "cholesky/lkjcholesky",
    "multivariate/vonmisesfisher",
    "conversion",
    "convolution",
    "mixture", # extra file compared to /src
    "gradlogpdf", # extra file compared to /src
    "univariate/continuous/noncentralt",
    "univariate/locationscale",
    "quantile_newton", # extra file compared to /src
    "univariate/continuous/semicircle",
    "qq",
    "univariate/continuous/pgeneralizedgaussian",
    "product",
    "namedtuple/productnamedtuple",
    "univariate/discrete/discretenonparametric",
    "univariate/continuous/chernoff",
    "univariate_bounds", # extra file compared to /src
    "univariate/discrete/negativebinomial",
    "univariate/discrete/geometric",
    "univariate/discrete/bernoulli",
    "univariate/discrete/poisson",
    "univariate/discrete/soliton",
    "univariate/continuous/skewnormal",
    "univariate/continuous/chi",
    "univariate/continuous/chisq",
    "univariate/continuous/erlang",
    "univariate/continuous/exponential",
    "univariate/continuous/gamma",
    "univariate/continuous/gumbel",
    "univariate/continuous/lindley",
    "univariate/continuous/logistic",
    "univariate/continuous/johnsonsu",
    "univariate/continuous/noncentralchisq",
    "univariate/continuous/weibull",
    "pdfnorm",
    "univariate/continuous/pareto",
    "univariate/continuous/rician",
    "functionals",
    "density_interface",
    "reshaped",
    "univariate/continuous/skewedexponentialpower",
    "univariate/discrete/discreteuniform",
    "univariate/continuous/tdist",
    "univariate/orderstatistic",
    "multivariate/jointorderstatistics",
    "multivariate/product",
    "eachvariate",
    "univariate/continuous/triangular",
    "statsapi",
    "univariate/continuous/inversegaussian",

    ### missing files compared to /src:
    # "common",
    # "estimators",
    # "genericfit",
    # "matrix/inversewishart",
    # "matrix/lkj",
    # "matrix/matrixbeta",
    # "matrix/matrixfdist",
    # "matrix/matrixnormal",
    # "matrix/matrixtdist",
    # "matrix/wishart",
    # "mixtures/mixturemodel",
    # "mixtures/unigmm",
    # "multivariate/mvnormalcanon",
    # "quantilealgs",
    # "samplers/aliastable",
    # "samplers/binomial",
    # "samplers/categorical",
    # "samplers/discretenonparametric",
    # "samplers/exponential",
    # "samplers/gamma",
    # "samplers/multinomial",
    # "samplers/obsoleted",
    # "samplers/poisson",
    # "samplers/poissonbinomial",
    # "samplers/vonmises",
    # "samplers/vonmisesfisher",
    # "show",
    # "truncated/loguniform",
    # "univariate/continuous/beta",
    # "univariate/continuous/beta",
    # "univariate/continuous/betaprime",
    # "univariate/continuous/biweight",
    # "univariate/continuous/cosine",
    # "univariate/continuous/epanechnikov",
    # "univariate/continuous/fdist",
    # "univariate/continuous/frechet",
    # "univariate/continuous/generalizedextremevalue",
    # "univariate/continuous/generalizedpareto",
    # "univariate/continuous/inversegamma",
    # "univariate/continuous/ksdist",
    # "univariate/continuous/ksonesided",
    # "univariate/continuous/levy",
    # "univariate/continuous/noncentralbeta",
    # "univariate/continuous/noncentralf",
    # "univariate/continuous/normalinversegaussian",
    # "univariate/continuous/rayleigh",
    # "univariate/continuous/studentizedrange",
    # "univariate/continuous/symtriangular",
    # "univariate/continuous/tdist",
    # "univariate/continuous/triweight",
    # "univariate/continuous/noncentralf",
    # "univariate/discrete/geometric",
    # "univariate/discrete/hypergeometric",
    # "univariate/discrete/noncentralhypergeometric",
    # "univariate/discrete/poisson",
    # "univariate/discrete/skellam",

    ### file is present but was not included in list
    # "multivariate_stats", # extra file compared to /src
    # "univariate/continuous/vonmises",
]

printstyled("Running tests:\n", color=:blue)

Random.seed!(345679)

# to reduce redundancy, we might break this file down into separate `$t * "_utils.jl"` files
include("../testutils.jl")

using Test, Distributions
using Random
using StatsBase

@testset "OrderStatistic" begin
    @testset "basic" begin
        for dist in [Uniform(), Normal(), DiscreteUniform(10)], n in [1, 2, 10], i in 1:n
            d = OrderStatistic(dist, n, i)
            @test d isa OrderStatistic
            if dist isa DiscreteUnivariateDistribution
                @test d isa DiscreteUnivariateDistribution
            else
                @test d isa ContinuousUnivariateDistribution
            end
            @test d.dist === dist
            @test d.n == n
            @test d.rank == i
        end
        @test_throws ArgumentError OrderStatistic(Normal(), 0, 1)
        OrderStatistic(Normal(), 0, 1; check_args=false)
        @test_throws ArgumentError OrderStatistic(Normal(), 10, 11)
        OrderStatistic(Normal(), 10, 11; check_args=false)
        @test_throws ArgumentError OrderStatistic(Normal(), 10, 0)
        OrderStatistic(Normal(), 10, 0; check_args=false)
    end

    @testset "params" begin
        for dist in [Uniform(), Normal(), DiscreteUniform(10)], n in [1, 2, 10], i in 1:n
            d = OrderStatistic(dist, n, i)
            @test params(d) == (params(dist)..., n, i)
            @test partype(d) === partype(dist)
        end
    end

    @testset "support" begin
        n = 10
        for i in 1:10
            d1 = OrderStatistic(Uniform(), n, i)
            @test minimum(d1) == 0
            @test maximum(d1) == 1
            @test insupport(d1, 0)
            @test insupport(d1, 0.5)
            @test insupport(d1, 1)
            @test !insupport(d1, -eps())
            @test !insupport(d1, 1 + eps())
            @test !hasfinitesupport(d1)
            @test islowerbounded(d1)
            @test isupperbounded(d1)

            d2 = OrderStatistic(Normal(), n, i)
            @test minimum(d2) == -Inf
            @test maximum(d2) == Inf
            @test insupport(d2, -Inf)
            @test insupport(d2, 0)
            @test insupport(d2, Inf)
            @test !hasfinitesupport(d2)
            @test !islowerbounded(d2)
            @test !isupperbounded(d2)

            d3 = OrderStatistic(DiscreteUniform(1, 10), n, i)
            @test minimum(d3) == 1
            @test maximum(d3) == 10
            @test insupport(d3, 1)
            @test insupport(d3, 5)
            @test insupport(d3, 10)
            @test !insupport(d3, 0)
            @test !insupport(d3, 11)
            @test hasfinitesupport(d3)
            @test islowerbounded(d3)
            @test isupperbounded(d3)
        end
    end

    @testset "pdf/logpdf" begin
        @testset "continuous" begin
            # test against the exact formula computed using BigFloats
            @testset for T in (Float32, Float64)
                @testset for dist in
                             [Uniform(T(-2), T(1)), Normal(T(3), T(2)), Exponential(T(10))],
                    n in [1, 10, 100],
                    i in 1:n

                    d = OrderStatistic(dist, n, i)
                    c = factorial(big(n)) / factorial(big(i - 1)) / factorial(big(n - i))
                    # since density is concentrated around the i/n quantile, sample a point
                    # nearby it
                    x = quantile(dist, clamp(i / n + (rand() - 1//2) / 10, 0, 1))
                    p = cdf(dist, big(x))
                    pdf_exp = c * p^(i - 1) * (1 - p)^(n - i) * pdf(dist, big(x))
                    @test @inferred(T, pdf(d, x)) ≈ T(pdf_exp)
                    @test @inferred(T, logpdf(d, x)) ≈ T(log(pdf_exp))
                end
            end
        end
        @testset "discrete" begin
            # test check that the pdf is the difference of the CDF at adjacent points
            @testset for dist in
                         [DiscreteUniform(10, 30), Poisson(100.0), Binomial(20, 0.3)],
                n in [1, 10, 100],
                i in 1:n

                d = OrderStatistic(dist, n, i)
                xs = quantile(dist, 0.01):quantile(dist, 0.99)
                for x in xs
                    p = @inferred pdf(d, x)
                    lp = @inferred logpdf(d, x)
                    @test lp ≈ logdiffcdf(d, x, x - 1)
                    @test p ≈ exp(lp)
                end
            end
        end
    end

    @testset "distribution normalizes to 1" begin
        @testset for dist in [
                Uniform(-2, 1),
                Normal(2, 3),
                Exponential(5),
                DiscreteUniform(10, 40),
                Poisson(100),
            ],
            n in [1, 10, 20],
            i in 1:n

            d = OrderStatistic(dist, n, i)
            Distributions.expectation(one, d) ≈ 1
        end
    end

    @testset "cdf/logcdf/ccdf/logccdf/quantile/cquantile" begin
        # test against the exact formula computed using BigFloats
        @testset for T in (Float32, Float64)
            dists = [
                (Uniform(T(-2), T(1)), Uniform(big(-2), big(1))),
                (Normal(T(3), T(2)), Normal(big(3), big(2))),
                (Exponential(T(10)), Exponential(big(10))),
                (DiscreteUniform(1, 10), DiscreteUniform(1, 10)),
                (Poisson(T(20)), Poisson(big(20))),
            ]
            @testset for (dist, bigdist) in dists, n in [10, 100], i in 1:n
                dist isa DiscreteDistribution && T !== Float64 && continue
                d = OrderStatistic(dist, n, i)
                # since density is concentrated around the i/n quantile, sample a point
                # nearby it
                x = quantile(dist, clamp(i / n + (rand() - 1//2) / 10, 1e-4, 1 - 1e-4))
                p = cdf(bigdist, big(x))
                cdf_exp = sum(i:n) do j
                    c = binomial(big(n), big(j))
                    return c * p^j * (1 - p)^(n - j)
                end
                @test @inferred(T, cdf(d, x)) ≈ T(cdf_exp)
                @test cdf(d, maximum(d)) ≈ one(T)
                @test cdf(d, minimum(d) - 1) ≈ zero(T)
                @test @inferred(T, logcdf(d, x)) ≈ T(log(cdf_exp))
                @test logcdf(d, maximum(d)) ≈ zero(T)
                @test logcdf(d, minimum(d) - 1) ≈ -Inf
                @test @inferred(T, ccdf(d, x)) ≈ T(1 - cdf_exp)
                @test ccdf(d, maximum(d)) ≈ zero(T)
                @test ccdf(d, minimum(d) - 1) ≈ one(T)
                @test @inferred(T, logccdf(d, x)) ≈ T(log(1 - cdf_exp))
                @test logccdf(d, maximum(d)) ≈ -Inf
                @test logccdf(d, minimum(d) - 1) ≈ zero(T)
                q = cdf(d, x)
                if dist isa DiscreteDistribution
                    # for discrete distributions, tiny numerical error can cause the wrong
                    # integer value to be returned.
                    q -= sqrt(eps(T))
                end
                xq = @inferred(T, quantile(d, q))
                xqc = @inferred(T, cquantile(d, 1 - q))
                @test xq ≈ xqc
                @test isapprox(xq, T(x); atol=1e-4) ||
                    (dist isa DiscreteDistribution && xq < x)
            end
        end
    end

    @testset "rand" begin
        @testset for T in [Float32, Float64],
            dist in [Uniform(T(-2), T(1)), Normal(T(1), T(2))]

            d = OrderStatistic(dist, 10, 5)
            rng = Random.default_rng()
            Random.seed!(rng, 42)
            x = @inferred(rand(rng, d))
            xs = @inferred(rand(rng, d, 10))
            S = eltype(rand(dist))
            @test typeof(x) === S
            @test eltype(xs) === S
            @test length(xs) == 10

            Random.seed!(rng, 42)
            x2 = rand(rng, d)
            xs2 = rand(rng, d, 10)
            @test x2 == x
            @test xs2 == xs
        end

        ndraws = 100_000
        nchecks = 4 * 2 * 111  # NOTE: update if the below number of tests changes
        α = (0.01 / nchecks) / 2  # multiple correction
        tol = quantile(Normal(), 1 - α)

        @testset for dist in [Uniform(), Exponential(), Poisson(20), Binomial(20, 0.3)]
            @testset for n in [1, 10, 100], i in 1:n
                d = OrderStatistic(dist, n, i)
                x = rand(d, ndraws)
                m, v = mean_and_var(x)
                if dist isa Uniform
                    # Arnold (2008). A first course in order statistics. Eqs 2.2.20-21
                    m_exact = i / (n + 1)
                    v_exact = m_exact * (1 - m_exact) / (n + 2)
                elseif dist isa Exponential
                    # Arnold (2008). A first course in order statistics. Eqs 4.6.6-7
                    m_exact = sum(k -> inv(n - k + 1), 1:i)
                    v_exact = sum(k -> inv((n - k + 1)^2), 1:i)
                elseif dist isa DiscreteUnivariateDistribution
                    # estimate mean and variance with explicit sum, Eqs 3.2.6-7 from
                    # Arnold (2008). A first course in order statistics.
                    xs = 0:quantile(dist, 0.9999)
                    m_exact = sum(x -> ccdf(d, x), xs)
                    v_exact = 2 * sum(x -> x * ccdf(d, x), xs) + m_exact - m_exact^2
                end
                # compute asymptotic sample standard deviation
                mean_std = sqrt(v_exact / ndraws)
                var_std = sqrt((moment(x, 4) - v_exact^2) / ndraws)
                @test m ≈ m_exact atol = (tol * mean_std)
                @test v ≈ v_exact atol = (tol * var_std)
            end
        end
    end
end

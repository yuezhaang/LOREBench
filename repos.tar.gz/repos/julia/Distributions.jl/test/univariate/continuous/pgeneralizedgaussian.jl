# Injected from runtests.jl
using Distributions
using PDMats # test dependencies
using Test
using Distributed
using Random
using SpecialFunctions
using StatsBase
using LinearAlgebra

import JSON
import ForwardDiff

const tests = [
    "aqua",
    "univariate/continuous/loguniform",
    "univariate/continuous/arcsine",
    "univariate/discrete/dirac",
    "truncate",
    "truncated/normal",
    "truncated/exponential",
    "truncated/uniform",
    "truncated/discrete_uniform",
    "censored",
    "univariate/continuous/normal",
    "univariate/continuous/normalcanon",
    "univariate/continuous/laplace",
    "univariate/continuous/cauchy",
    "univariate/continuous/uniform",
    "univariate/continuous/lognormal",
    "multivariate/mvnormal",
    "multivariate/mvlogitnormal",
    "multivariate/mvlognormal",
    "types", # extra file compared to /src
    "utils",
    "samplers",
    "univariate/discrete/categorical",
    "univariates",
    "univariate/continuous", # extra file compared to /src
    "edgecases", # extra file compared to /src
    "fit", # extra file compared to /src
    "multivariate/multinomial",
    "univariate/discrete/binomial",
    "univariate/discrete/betabinomial",
    "univariate/discrete/poissonbinomial",
    "multivariate/dirichlet",
    "multivariate/dirichletmultinomial",
    "univariate/continuous/logitnormal",
    "multivariate/mvtdist",
    "univariate/continuous/kolmogorov",
    "edgeworth",
    "matrixreshaped", # extra file compared to /src
    "matrixvariates",
    "cholesky/lkjcholesky",
    "multivariate/vonmisesfisher",
    "conversion",
    "convolution",
    "mixture", # extra file compared to /src
    "gradlogpdf", # extra file compared to /src
    "univariate/continuous/noncentralt",
    "univariate/locationscale",
    "quantile_newton", # extra file compared to /src
    "univariate/continuous/semicircle",
    "qq",
    "univariate/continuous/pgeneralizedgaussian",
    "product",
    "namedtuple/productnamedtuple",
    "univariate/discrete/discretenonparametric",
    "univariate/continuous/chernoff",
    "univariate_bounds", # extra file compared to /src
    "univariate/discrete/negativebinomial",
    "univariate/discrete/geometric",
    "univariate/discrete/bernoulli",
    "univariate/discrete/poisson",
    "univariate/discrete/soliton",
    "univariate/continuous/skewnormal",
    "univariate/continuous/chi",
    "univariate/continuous/chisq",
    "univariate/continuous/erlang",
    "univariate/continuous/exponential",
    "univariate/continuous/gamma",
    "univariate/continuous/gumbel",
    "univariate/continuous/lindley",
    "univariate/continuous/logistic",
    "univariate/continuous/johnsonsu",
    "univariate/continuous/noncentralchisq",
    "univariate/continuous/weibull",
    "pdfnorm",
    "univariate/continuous/pareto",
    "univariate/continuous/rician",
    "functionals",
    "density_interface",
    "reshaped",
    "univariate/continuous/skewedexponentialpower",
    "univariate/discrete/discreteuniform",
    "univariate/continuous/tdist",
    "univariate/orderstatistic",
    "multivariate/jointorderstatistics",
    "multivariate/product",
    "eachvariate",
    "univariate/continuous/triangular",
    "statsapi",
    "univariate/continuous/inversegaussian",

    ### missing files compared to /src:
    # "common",
    # "estimators",
    # "genericfit",
    # "matrix/inversewishart",
    # "matrix/lkj",
    # "matrix/matrixbeta",
    # "matrix/matrixfdist",
    # "matrix/matrixnormal",
    # "matrix/matrixtdist",
    # "matrix/wishart",
    # "mixtures/mixturemodel",
    # "mixtures/unigmm",
    # "multivariate/mvnormalcanon",
    # "quantilealgs",
    # "samplers/aliastable",
    # "samplers/binomial",
    # "samplers/categorical",
    # "samplers/discretenonparametric",
    # "samplers/exponential",
    # "samplers/gamma",
    # "samplers/multinomial",
    # "samplers/obsoleted",
    # "samplers/poisson",
    # "samplers/poissonbinomial",
    # "samplers/vonmises",
    # "samplers/vonmisesfisher",
    # "show",
    # "truncated/loguniform",
    # "univariate/continuous/beta",
    # "univariate/continuous/beta",
    # "univariate/continuous/betaprime",
    # "univariate/continuous/biweight",
    # "univariate/continuous/cosine",
    # "univariate/continuous/epanechnikov",
    # "univariate/continuous/fdist",
    # "univariate/continuous/frechet",
    # "univariate/continuous/generalizedextremevalue",
    # "univariate/continuous/generalizedpareto",
    # "univariate/continuous/inversegamma",
    # "univariate/continuous/ksdist",
    # "univariate/continuous/ksonesided",
    # "univariate/continuous/levy",
    # "univariate/continuous/noncentralbeta",
    # "univariate/continuous/noncentralf",
    # "univariate/continuous/normalinversegaussian",
    # "univariate/continuous/rayleigh",
    # "univariate/continuous/studentizedrange",
    # "univariate/continuous/symtriangular",
    # "univariate/continuous/tdist",
    # "univariate/continuous/triweight",
    # "univariate/continuous/noncentralf",
    # "univariate/discrete/geometric",
    # "univariate/discrete/hypergeometric",
    # "univariate/discrete/noncentralhypergeometric",
    # "univariate/discrete/poisson",
    # "univariate/discrete/skellam",

    ### file is present but was not included in list
    # "multivariate_stats", # extra file compared to /src
    # "univariate/continuous/vonmises",
]

printstyled("Running tests:\n", color=:blue)

Random.seed!(345679)

# to reduce redundancy, we might break this file down into separate `$t * "_utils.jl"` files
include("../../testutils.jl")

using Distributions

using Random
using Test

@testset "PGeneralizedGaussian" begin
    @testset "Constructors" begin
        # Argument checks
        μ = randn()
        for p in (-0.2, 0)
            @test_throws DomainError PGeneralizedGaussian(p)
            PGeneralizedGaussian(p; check_args=false)

            @test_throws DomainError PGeneralizedGaussian(μ, 1.0, p)
            PGeneralizedGaussian(μ, 1.0, p; check_args=false)
        end
        for α in (-1.2, 0)
            @test_throws DomainError PGeneralizedGaussian(μ, α, 1.0)
            PGeneralizedGaussian(μ, α, 1.0; check_args=false)

            for p in (-0.2, 0)
                @test_throws DomainError PGeneralizedGaussian(μ, α, p)
                PGeneralizedGaussian(μ, α, p; check_args=false)
            end
        end

        # Convenience constructors
        d = PGeneralizedGaussian()
        @test d.μ == 0
        @test d.α ≈ sqrt(2)
        @test d.p == 2

        d = PGeneralizedGaussian(2.1)
        @test d.μ == 0
        @test d.α == 1
        @test d.p == 2.1
    end

    @testset "Special cases" begin
        μ = randn()
        α = Random.randexp()
        for (d, dref) in (
            (PGeneralizedGaussian(μ, α, 1), Laplace(μ, α)), # p = 1 (Laplace)
            (PGeneralizedGaussian(), Normal()), # p = 2 (standard normal)
            (PGeneralizedGaussian(μ, α, 2), Normal(μ, α / sqrt(2))), # p = 2 (normal)
        )
            @test minimum(d) == -Inf
            @test maximum(d) == Inf

            @test location(d) == d.μ
            @test scale(d) == d.α
            @test shape(d) == d.p

            @test mean(d) == d.μ
            @test mean(d) ≈ mean(dref)
            @test median(d) == d.μ
            @test median(d) ≈ median(dref)
            @test mode(d) == d.μ
            @test mode(d) ≈ mode(dref)

            @test var(d) ≈ var(dref)
            @test std(d) ≈ std(dref)

            @test skewness(d) == 0
            @test kurtosis(d) ≈ kurtosis(dref) atol = 1e-12
            @test entropy(d) ≈ entropy(dref)

            # PDF + CDF tests.
            for x in (-Inf, d.μ - 4.2, d.μ - 1.2, d.μ, Float32(d.μ) + 0.3f0, d.μ + 4, Inf32)
                @test @inferred(pdf(d, x)) ≈ pdf(dref, x)
                @test @inferred(logpdf(d, x)) ≈ logpdf(dref, x)
                @test @inferred(cdf(d, x)) ≈ cdf(dref, x) atol = 1e-12
                @test @inferred(logcdf(d, x)) ≈ logcdf(dref, x) atol = 1e-12
            end

            # Additional tests, including sampling
            test_distr(d, 10^6)
        end
    end

    @testset "Non-special case" begin
        μ = randn()
        α = Random.randexp()
        p = Random.randexp()
        d = PGeneralizedGaussian(μ, α, p)

        @test minimum(d) == -Inf
        @test maximum(d) == Inf

        @test location(d) == μ
        @test scale(d) == α
        @test shape(d) == p

        @test mean(d) == μ
        @test median(d) == μ
        @test mode(d) == μ

        @test cdf(d, -Inf) == 0
        @test logcdf(d, -Inf) == -Inf
        @test cdf(d, μ) ≈ 0.5
        @test logcdf(d, μ) ≈ -log(2)
        @test cdf(d, Inf) == 1
        @test logcdf(d, Inf) == 0
        @test quantile(d, 1 // 2) ≈ μ

        # Additional tests, including sampling
        test_distr(d, 10^6)
    end

    # issue #1916
    @testset "Underflow in logccdf" begin
        d = PGeneralizedGaussian(2.5)

        # (c)cdf became more accurate
        @test isfinite(log(cdf(d, -5.0)))
        @test isfinite(log(ccdf(d, 5.0)))
        @test ccdf(d, 5.0) ≈ cdf(d, -5.0)

        # We have to use -20 to provoke the issue
        @test log(cdf(d, -20.0)) === -Inf
        @test log(ccdf(d, 20.0)) === -Inf
        @test isfinite(logcdf(d, -20.0))
        @test logccdf(d, 20.0) ≈ logcdf(d, -20.0)
    end
end

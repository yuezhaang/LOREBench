# Injected from runtests.jl
using Distributions
using PDMats # test dependencies
using Test
using Distributed
using Random
using SpecialFunctions
using StatsBase
using LinearAlgebra

import JSON
import ForwardDiff

const tests = [
    "aqua",
    "univariate/continuous/loguniform",
    "univariate/continuous/arcsine",
    "univariate/discrete/dirac",
    "truncate",
    "truncated/normal",
    "truncated/exponential",
    "truncated/uniform",
    "truncated/discrete_uniform",
    "censored",
    "univariate/continuous/normal",
    "univariate/continuous/normalcanon",
    "univariate/continuous/laplace",
    "univariate/continuous/cauchy",
    "univariate/continuous/uniform",
    "univariate/continuous/lognormal",
    "multivariate/mvnormal",
    "multivariate/mvlogitnormal",
    "multivariate/mvlognormal",
    "types", # extra file compared to /src
    "utils",
    "samplers",
    "univariate/discrete/categorical",
    "univariates",
    "univariate/continuous", # extra file compared to /src
    "edgecases", # extra file compared to /src
    "fit", # extra file compared to /src
    "multivariate/multinomial",
    "univariate/discrete/binomial",
    "univariate/discrete/betabinomial",
    "univariate/discrete/poissonbinomial",
    "multivariate/dirichlet",
    "multivariate/dirichletmultinomial",
    "univariate/continuous/logitnormal",
    "multivariate/mvtdist",
    "univariate/continuous/kolmogorov",
    "edgeworth",
    "matrixreshaped", # extra file compared to /src
    "matrixvariates",
    "cholesky/lkjcholesky",
    "multivariate/vonmisesfisher",
    "conversion",
    "convolution",
    "mixture", # extra file compared to /src
    "gradlogpdf", # extra file compared to /src
    "univariate/continuous/noncentralt",
    "univariate/locationscale",
    "quantile_newton", # extra file compared to /src
    "univariate/continuous/semicircle",
    "qq",
    "univariate/continuous/pgeneralizedgaussian",
    "product",
    "namedtuple/productnamedtuple",
    "univariate/discrete/discretenonparametric",
    "univariate/continuous/chernoff",
    "univariate_bounds", # extra file compared to /src
    "univariate/discrete/negativebinomial",
    "univariate/discrete/geometric",
    "univariate/discrete/bernoulli",
    "univariate/discrete/poisson",
    "univariate/discrete/soliton",
    "univariate/continuous/skewnormal",
    "univariate/continuous/chi",
    "univariate/continuous/chisq",
    "univariate/continuous/erlang",
    "univariate/continuous/exponential",
    "univariate/continuous/gamma",
    "univariate/continuous/gumbel",
    "univariate/continuous/lindley",
    "univariate/continuous/logistic",
    "univariate/continuous/johnsonsu",
    "univariate/continuous/noncentralchisq",
    "univariate/continuous/weibull",
    "pdfnorm",
    "univariate/continuous/pareto",
    "univariate/continuous/rician",
    "functionals",
    "density_interface",
    "reshaped",
    "univariate/continuous/skewedexponentialpower",
    "univariate/discrete/discreteuniform",
    "univariate/continuous/tdist",
    "univariate/orderstatistic",
    "multivariate/jointorderstatistics",
    "multivariate/product",
    "eachvariate",
    "univariate/continuous/triangular",
    "statsapi",
    "univariate/continuous/inversegaussian",

    ### missing files compared to /src:
    # "common",
    # "estimators",
    # "genericfit",
    # "matrix/inversewishart",
    # "matrix/lkj",
    # "matrix/matrixbeta",
    # "matrix/matrixfdist",
    # "matrix/matrixnormal",
    # "matrix/matrixtdist",
    # "matrix/wishart",
    # "mixtures/mixturemodel",
    # "mixtures/unigmm",
    # "multivariate/mvnormalcanon",
    # "quantilealgs",
    # "samplers/aliastable",
    # "samplers/binomial",
    # "samplers/categorical",
    # "samplers/discretenonparametric",
    # "samplers/exponential",
    # "samplers/gamma",
    # "samplers/multinomial",
    # "samplers/obsoleted",
    # "samplers/poisson",
    # "samplers/poissonbinomial",
    # "samplers/vonmises",
    # "samplers/vonmisesfisher",
    # "show",
    # "truncated/loguniform",
    # "univariate/continuous/beta",
    # "univariate/continuous/beta",
    # "univariate/continuous/betaprime",
    # "univariate/continuous/biweight",
    # "univariate/continuous/cosine",
    # "univariate/continuous/epanechnikov",
    # "univariate/continuous/fdist",
    # "univariate/continuous/frechet",
    # "univariate/continuous/generalizedextremevalue",
    # "univariate/continuous/generalizedpareto",
    # "univariate/continuous/inversegamma",
    # "univariate/continuous/ksdist",
    # "univariate/continuous/ksonesided",
    # "univariate/continuous/levy",
    # "univariate/continuous/noncentralbeta",
    # "univariate/continuous/noncentralf",
    # "univariate/continuous/normalinversegaussian",
    # "univariate/continuous/rayleigh",
    # "univariate/continuous/studentizedrange",
    # "univariate/continuous/symtriangular",
    # "univariate/continuous/tdist",
    # "univariate/continuous/triweight",
    # "univariate/continuous/noncentralf",
    # "univariate/discrete/geometric",
    # "univariate/discrete/hypergeometric",
    # "univariate/discrete/noncentralhypergeometric",
    # "univariate/discrete/poisson",
    # "univariate/discrete/skellam",

    ### file is present but was not included in list
    # "multivariate_stats", # extra file compared to /src
    # "univariate/continuous/vonmises",
]

printstyled("Running tests:\n", color=:blue)

Random.seed!(345679)

# to reduce redundancy, we might break this file down into separate `$t * "_utils.jl"` files
include("../../testutils.jl")

using Distributions
using FiniteDifferences
using ForwardDiff
using Random
using Test

using Base: Fix1
using Distributions: expectation

@testset "Lindley" begin
    @testset "NaNs" begin
        D = Lindley()
        for f in (pdf, logpdf, gradlogpdf, cdf, ccdf, logcdf, logccdf, mgf, cgf, cf)
            @test isnan(f(D, NaN))
        end
    end
    @testset "MLE" begin
        rng = MersenneTwister(420)
        samples = rand(rng, Lindley(1.5f0), 10_000)
        mle = fit_mle(Lindley, samples)
        @test mle isa Lindley
        @test shape(mle) ≈ 1.5 atol=0.1
    end
    @testset "$T" for T in (Float16, Float32, Float64, Rational{Int})
        D = Lindley(one(T))
        @test partype(D) === T
        @test typeof(@inferred rand(D)) === typeof(rand())
        @test @inferred(mean(D)) == T(3/2)
        tol = sqrt(eps(float(T)))
        @testset "Gradient of log PDF" begin
            for x in T(0):T(0.5):T(20)
                fd = ForwardDiff.derivative(Fix1(logpdf, D), x)
                gl = @inferred gradlogpdf(D, x)
                @test gl isa T
                @test fd ≈ gl atol=tol
            end
        end
        @testset "Entropy" begin
            shannon = @inferred entropy(D)
            expect = T(expectation(x -> -logpdf(D, x), D))
            if T <: AbstractFloat
                @test shannon isa T
            end
            @test shannon ≈ expect atol=tol
        end
        @testset "K-L divergence" begin
            S = supertype(typeof(D))
            D₂ = Lindley(T(2))
            d₁ = kldivergence(D, D₂)
            d₂ = invoke(kldivergence, Tuple{S,S}, D, D₂)
            if T <: AbstractFloat
                @test d₁ isa T
            end
            @test d₁ ≈ d₂ atol=tol
        end
        @testset "Mode" begin
            @test iszero(@inferred mode(D))
            @test isone(mode(Lindley(T(0.5))))
            m = mode(Lindley(T(0.1)))
            @test m isa T
            @test m ≈ T(9) atol=tol
        end
        @testset "Skewness" begin
            μ = mean(D)
            σ = std(D)
            s₁ = @inferred skewness(D)
            s₂ = T(expectation(x -> ((x - μ) / σ)^3, D))
            if T <: AbstractFloat
                @test s₁ isa T
            end
            @test s₁ ≈ s₂ atol=sqrt(tol)
        end
        @testset "MGF, CGF, CF" begin
            @test @inferred(mgf(D, 0)) === one(T)
            @test iszero(mgf(D, shape(D) + 1))
            @test ForwardDiff.derivative(Fix1(mgf, D), 0) ≈ mean(D)
            @test central_fdm(5, 1)(Fix1(cf, D), 0) ≈ mean(D) * im
            test_cgf(D, (-1e6, -100f0, Float16(-1), 1//10, 0.9))
        end
    end
end

# Injected from runtests.jl
using Distributions
using PDMats # test dependencies
using Test
using Distributed
using Random
using SpecialFunctions
using StatsBase
using LinearAlgebra

import JSON
import ForwardDiff

const tests = [
    "aqua",
    "univariate/continuous/loguniform",
    "univariate/continuous/arcsine",
    "univariate/discrete/dirac",
    "truncate",
    "truncated/normal",
    "truncated/exponential",
    "truncated/uniform",
    "truncated/discrete_uniform",
    "censored",
    "univariate/continuous/normal",
    "univariate/continuous/normalcanon",
    "univariate/continuous/laplace",
    "univariate/continuous/cauchy",
    "univariate/continuous/uniform",
    "univariate/continuous/lognormal",
    "multivariate/mvnormal",
    "multivariate/mvlogitnormal",
    "multivariate/mvlognormal",
    "types", # extra file compared to /src
    "utils",
    "samplers",
    "univariate/discrete/categorical",
    "univariates",
    "univariate/continuous", # extra file compared to /src
    "edgecases", # extra file compared to /src
    "fit", # extra file compared to /src
    "multivariate/multinomial",
    "univariate/discrete/binomial",
    "univariate/discrete/betabinomial",
    "univariate/discrete/poissonbinomial",
    "multivariate/dirichlet",
    "multivariate/dirichletmultinomial",
    "univariate/continuous/logitnormal",
    "multivariate/mvtdist",
    "univariate/continuous/kolmogorov",
    "edgeworth",
    "matrixreshaped", # extra file compared to /src
    "matrixvariates",
    "cholesky/lkjcholesky",
    "multivariate/vonmisesfisher",
    "conversion",
    "convolution",
    "mixture", # extra file compared to /src
    "gradlogpdf", # extra file compared to /src
    "univariate/continuous/noncentralt",
    "univariate/locationscale",
    "quantile_newton", # extra file compared to /src
    "univariate/continuous/semicircle",
    "qq",
    "univariate/continuous/pgeneralizedgaussian",
    "product",
    "namedtuple/productnamedtuple",
    "univariate/discrete/discretenonparametric",
    "univariate/continuous/chernoff",
    "univariate_bounds", # extra file compared to /src
    "univariate/discrete/negativebinomial",
    "univariate/discrete/geometric",
    "univariate/discrete/bernoulli",
    "univariate/discrete/poisson",
    "univariate/discrete/soliton",
    "univariate/continuous/skewnormal",
    "univariate/continuous/chi",
    "univariate/continuous/chisq",
    "univariate/continuous/erlang",
    "univariate/continuous/exponential",
    "univariate/continuous/gamma",
    "univariate/continuous/gumbel",
    "univariate/continuous/lindley",
    "univariate/continuous/logistic",
    "univariate/continuous/johnsonsu",
    "univariate/continuous/noncentralchisq",
    "univariate/continuous/weibull",
    "pdfnorm",
    "univariate/continuous/pareto",
    "univariate/continuous/rician",
    "functionals",
    "density_interface",
    "reshaped",
    "univariate/continuous/skewedexponentialpower",
    "univariate/discrete/discreteuniform",
    "univariate/continuous/tdist",
    "univariate/orderstatistic",
    "multivariate/jointorderstatistics",
    "multivariate/product",
    "eachvariate",
    "univariate/continuous/triangular",
    "statsapi",
    "univariate/continuous/inversegaussian",

    ### missing files compared to /src:
    # "common",
    # "estimators",
    # "genericfit",
    # "matrix/inversewishart",
    # "matrix/lkj",
    # "matrix/matrixbeta",
    # "matrix/matrixfdist",
    # "matrix/matrixnormal",
    # "matrix/matrixtdist",
    # "matrix/wishart",
    # "mixtures/mixturemodel",
    # "mixtures/unigmm",
    # "multivariate/mvnormalcanon",
    # "quantilealgs",
    # "samplers/aliastable",
    # "samplers/binomial",
    # "samplers/categorical",
    # "samplers/discretenonparametric",
    # "samplers/exponential",
    # "samplers/gamma",
    # "samplers/multinomial",
    # "samplers/obsoleted",
    # "samplers/poisson",
    # "samplers/poissonbinomial",
    # "samplers/vonmises",
    # "samplers/vonmisesfisher",
    # "show",
    # "truncated/loguniform",
    # "univariate/continuous/beta",
    # "univariate/continuous/beta",
    # "univariate/continuous/betaprime",
    # "univariate/continuous/biweight",
    # "univariate/continuous/cosine",
    # "univariate/continuous/epanechnikov",
    # "univariate/continuous/fdist",
    # "univariate/continuous/frechet",
    # "univariate/continuous/generalizedextremevalue",
    # "univariate/continuous/generalizedpareto",
    # "univariate/continuous/inversegamma",
    # "univariate/continuous/ksdist",
    # "univariate/continuous/ksonesided",
    # "univariate/continuous/levy",
    # "univariate/continuous/noncentralbeta",
    # "univariate/continuous/noncentralf",
    # "univariate/continuous/normalinversegaussian",
    # "univariate/continuous/rayleigh",
    # "univariate/continuous/studentizedrange",
    # "univariate/continuous/symtriangular",
    # "univariate/continuous/tdist",
    # "univariate/continuous/triweight",
    # "univariate/continuous/noncentralf",
    # "univariate/discrete/geometric",
    # "univariate/discrete/hypergeometric",
    # "univariate/discrete/noncentralhypergeometric",
    # "univariate/discrete/poisson",
    # "univariate/discrete/skellam",

    ### file is present but was not included in list
    # "multivariate_stats", # extra file compared to /src
    # "univariate/continuous/vonmises",
]

printstyled("Running tests:\n", color=:blue)

Random.seed!(345679)

# to reduce redundancy, we might break this file down into separate `$t * "_utils.jl"` files
include("../../testutils.jl")

module TestLogUniform
using Test
using Distributions
import Random

@testset "LogUniform" begin
    rng = Random.MersenneTwister(0)

    @test pdf(LogUniform(1f0, 2f0), 1) isa Float32
    @test pdf(LogUniform(1, 2), 1f0) isa Float32
    @test pdf(LogUniform(1, 2), 1) isa Float64
    @test quantile(LogUniform(1, 2), 1) isa Float64
    @test quantile(LogUniform(1, 2), 1f0) isa Float32
    @testset "$f" for f in [pdf, cdf, quantile, logpdf, logcdf]
        @test @inferred(f(LogUniform(1,2), 1)) isa Float64
        @test @inferred(f(LogUniform(1,2), 1.0)) isa Float64
        @test @inferred(f(LogUniform(1.0,2), 1.0)) isa Float64
        @test @inferred(f(LogUniform(1.0f0,2), 1)) isa Float32
        @test @inferred(f(LogUniform(1.0f0,2), 1f0)) isa Float32
        @test @inferred(f(LogUniform(1,2), 1f0)) isa Float32
    end

    d = LogUniform(1,10)
    @test eltype(d) === Float64
    @test 1 <= rand(rng, d) <= 10
    @test rand(rng, d) isa eltype(d)
    @test @inferred(quantile(d, 0))   ≈ 1
    @test quantile(d, 0.5) ≈ sqrt(10) # geomean
    @test quantile(d, 1)   ≈ 10
    @test mode(d) ≈ 1
    @test !insupport(d, 0)
    @test @inferred(minimum(d)) === 1
    @test @inferred(maximum(d)) === 10
    @test partype(d) === Int
    @test truncated(d, 2, 14) === LogUniform(2,10)
    @test truncated(d, 0, 8) === LogUniform(1, 8)
    @test truncated(d; upper=8) === LogUniform(1, 8)
    @test truncated(d; lower=3) === LogUniform(3, 10)

    # numbers obtained by calling scipy.stats.loguniform
    @test @inferred(std(d)        ) ≈ 2.49399867607628
    @test @inferred(mean(d)       ) ≈ 3.908650337129266
    @test @inferred(pdf(d, 1.0001)) ≈ 0.43425105679757203
    @test @inferred(pdf(d, 5     )) ≈ 0.08685889638065035
    @test @inferred(pdf(d, 9.9999)) ≈ 0.04342988248915007
    @test @inferred(cdf(d, 1.0001)) ≈ 4.342727686266485e-05
    @test @inferred(cdf(d, 5     )) ≈ 0.6989700043360187
    @test @inferred(cdf(d, 9.9999)) ≈ 0.999995657033466
    @test @inferred(median(d)     ) ≈ 3.1622776601683795
    @test @inferred(logpdf(d, 5)  ) ≈ -2.443470357682056

    for _ in 1:10
        lo = rand(rng)
        hi = lo + 10*rand(rng)
        dist = LogUniform(lo,hi)
        q = rand(rng)
        @test cdf(dist, quantile(dist, q)) ≈ q

        u = Uniform(log(lo), log(hi))
        @test exp(quantile(u, q)) ≈ quantile(dist, q)
        @test exp(median(u)) ≈ median(dist)
        x = rand(rng, dist)
        @test cdf(u, log(x)) ≈ cdf(dist, x)

        @test @inferred(entropy(dist)) ≈  Distributions.expectation(x->-logpdf(dist,x), dist)
    end

    @test kldivergence(LogUniform(1,2), LogUniform(1,2)) ≈ 0 atol=100eps(Float64)
    @test isfinite(kldivergence(LogUniform(1,2), LogUniform(1,10)))
    @test kldivergence(LogUniform(1.1,10), LogUniform(1,2)) === Inf
    @test kldivergence(LogUniform(0.1,10), LogUniform(1,2)) === Inf
    @test kldivergence(LogUniform(0.1,1), LogUniform(1,2))  === Inf
    @test @inferred(kldivergence(LogUniform(0.1f0,1), LogUniform(1,2)))  === Inf32

    for _ in 1:10
        aq = 10*rand(rng)
        ap = aq + 10*rand(rng)
        bp = ap + 10*rand(rng)
        bq = bp + 10*rand(rng)
        p = LogUniform(ap, bp)
        q = LogUniform(aq, bq)
        @test @inferred(kldivergence(p, q)) ≈
            kldivergence(Uniform(log(ap), log(bp)), Uniform(log(aq), log(bq)))
    end
end


end#module

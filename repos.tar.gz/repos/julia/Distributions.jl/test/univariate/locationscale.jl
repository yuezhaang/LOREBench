# Injected from runtests.jl
using Distributions
using PDMats # test dependencies
using Test
using Distributed
using Random
using SpecialFunctions
using StatsBase
using LinearAlgebra

import JSON
import ForwardDiff

const tests = [
    "aqua",
    "univariate/continuous/loguniform",
    "univariate/continuous/arcsine",
    "univariate/discrete/dirac",
    "truncate",
    "truncated/normal",
    "truncated/exponential",
    "truncated/uniform",
    "truncated/discrete_uniform",
    "censored",
    "univariate/continuous/normal",
    "univariate/continuous/normalcanon",
    "univariate/continuous/laplace",
    "univariate/continuous/cauchy",
    "univariate/continuous/uniform",
    "univariate/continuous/lognormal",
    "multivariate/mvnormal",
    "multivariate/mvlogitnormal",
    "multivariate/mvlognormal",
    "types", # extra file compared to /src
    "utils",
    "samplers",
    "univariate/discrete/categorical",
    "univariates",
    "univariate/continuous", # extra file compared to /src
    "edgecases", # extra file compared to /src
    "fit", # extra file compared to /src
    "multivariate/multinomial",
    "univariate/discrete/binomial",
    "univariate/discrete/betabinomial",
    "univariate/discrete/poissonbinomial",
    "multivariate/dirichlet",
    "multivariate/dirichletmultinomial",
    "univariate/continuous/logitnormal",
    "multivariate/mvtdist",
    "univariate/continuous/kolmogorov",
    "edgeworth",
    "matrixreshaped", # extra file compared to /src
    "matrixvariates",
    "cholesky/lkjcholesky",
    "multivariate/vonmisesfisher",
    "conversion",
    "convolution",
    "mixture", # extra file compared to /src
    "gradlogpdf", # extra file compared to /src
    "univariate/continuous/noncentralt",
    "univariate/locationscale",
    "quantile_newton", # extra file compared to /src
    "univariate/continuous/semicircle",
    "qq",
    "univariate/continuous/pgeneralizedgaussian",
    "product",
    "namedtuple/productnamedtuple",
    "univariate/discrete/discretenonparametric",
    "univariate/continuous/chernoff",
    "univariate_bounds", # extra file compared to /src
    "univariate/discrete/negativebinomial",
    "univariate/discrete/geometric",
    "univariate/discrete/bernoulli",
    "univariate/discrete/poisson",
    "univariate/discrete/soliton",
    "univariate/continuous/skewnormal",
    "univariate/continuous/chi",
    "univariate/continuous/chisq",
    "univariate/continuous/erlang",
    "univariate/continuous/exponential",
    "univariate/continuous/gamma",
    "univariate/continuous/gumbel",
    "univariate/continuous/lindley",
    "univariate/continuous/logistic",
    "univariate/continuous/johnsonsu",
    "univariate/continuous/noncentralchisq",
    "univariate/continuous/weibull",
    "pdfnorm",
    "univariate/continuous/pareto",
    "univariate/continuous/rician",
    "functionals",
    "density_interface",
    "reshaped",
    "univariate/continuous/skewedexponentialpower",
    "univariate/discrete/discreteuniform",
    "univariate/continuous/tdist",
    "univariate/orderstatistic",
    "multivariate/jointorderstatistics",
    "multivariate/product",
    "eachvariate",
    "univariate/continuous/triangular",
    "statsapi",
    "univariate/continuous/inversegaussian",

    ### missing files compared to /src:
    # "common",
    # "estimators",
    # "genericfit",
    # "matrix/inversewishart",
    # "matrix/lkj",
    # "matrix/matrixbeta",
    # "matrix/matrixfdist",
    # "matrix/matrixnormal",
    # "matrix/matrixtdist",
    # "matrix/wishart",
    # "mixtures/mixturemodel",
    # "mixtures/unigmm",
    # "multivariate/mvnormalcanon",
    # "quantilealgs",
    # "samplers/aliastable",
    # "samplers/binomial",
    # "samplers/categorical",
    # "samplers/discretenonparametric",
    # "samplers/exponential",
    # "samplers/gamma",
    # "samplers/multinomial",
    # "samplers/obsoleted",
    # "samplers/poisson",
    # "samplers/poissonbinomial",
    # "samplers/vonmises",
    # "samplers/vonmisesfisher",
    # "show",
    # "truncated/loguniform",
    # "univariate/continuous/beta",
    # "univariate/continuous/beta",
    # "univariate/continuous/betaprime",
    # "univariate/continuous/biweight",
    # "univariate/continuous/cosine",
    # "univariate/continuous/epanechnikov",
    # "univariate/continuous/fdist",
    # "univariate/continuous/frechet",
    # "univariate/continuous/generalizedextremevalue",
    # "univariate/continuous/generalizedpareto",
    # "univariate/continuous/inversegamma",
    # "univariate/continuous/ksdist",
    # "univariate/continuous/ksonesided",
    # "univariate/continuous/levy",
    # "univariate/continuous/noncentralbeta",
    # "univariate/continuous/noncentralf",
    # "univariate/continuous/normalinversegaussian",
    # "univariate/continuous/rayleigh",
    # "univariate/continuous/studentizedrange",
    # "univariate/continuous/symtriangular",
    # "univariate/continuous/tdist",
    # "univariate/continuous/triweight",
    # "univariate/continuous/noncentralf",
    # "univariate/discrete/geometric",
    # "univariate/discrete/hypergeometric",
    # "univariate/discrete/noncentralhypergeometric",
    # "univariate/discrete/poisson",
    # "univariate/discrete/skellam",

    ### file is present but was not included in list
    # "multivariate_stats", # extra file compared to /src
    # "univariate/continuous/vonmises",
]

printstyled("Running tests:\n", color=:blue)

Random.seed!(345679)

# to reduce redundancy, we might break this file down into separate `$t * "_utils.jl"` files
include("../testutils.jl")

function test_location_scale(
    rng::Union{AbstractRNG, Missing},
    μ::Real, σ::Real, ρ::UnivariateDistribution, dref::UnivariateDistribution,
)
    d = Distributions.AffineDistribution(μ, σ, ρ)
    @test params(d) == (μ,σ,ρ)
    @test eltype(d) === eltype(dref)

    # Different ways to construct the AffineDistribution object
    if dref isa DiscreteDistribution
        # floating point division introduces numerical errors
        # Better: multiply with rational numbers
        d_dict = Dict(
            "original" => d,
            "sugar" => σ * ρ + μ,
        )
    else
        d_dict = Dict(
            "original" => d,
            "sugar" => σ * ρ + μ,
            "composed" =>  μ + ((2 * ρ) * σ - 2) / 2 + 1
        )
    end

    @test d == deepcopy(d)

    #### Support / Domain

    @testset "Support" begin
        @testset "$k" for (k,dtest) in d_dict
            @test minimum(dtest) == minimum(dref)
            @test maximum(dtest) == maximum(dref)
            @test extrema(dtest) == (minimum(dref), maximum(dref))
            @test extrema(support(dtest)) == extrema(dref)
            @test support(dtest) == support(dref)
        end
    end

    #### Promotions and conversions

    @testset "Promotions and conversions" begin
        @testset "$k" for (k,dtest) in d_dict
            if dtest isa Distributions.AffineDistribution
                @test typeof(dtest.μ) === typeof(dtest.σ)
                @test location(dtest) ≈ μ atol=1e-15
                @test    scale(dtest) ≈ σ atol=1e-15
            end
        end
    end

    #### Statistics

    @testset "Statistics" begin
        @testset "$k" for (k,dtest) in d_dict
            @test mean(dtest) ≈ mean(dref)
            @test median(dtest) ≈ median(dref)
            @test mode(dtest) ≈ mode(dref)
            @test modes(dtest) ≈ modes(dref)

            @test var(dtest) ≈ var(dref)
            @test std(dtest) ≈ std(dref)

            @test skewness(dtest) ≈ skewness(dref)
            @test kurtosis(dtest) ≈ kurtosis(dref)

            @test isplatykurtic(dtest) == isplatykurtic(dref)
            @test isleptokurtic(dtest) == isleptokurtic(dref)
            @test ismesokurtic(dtest) == ismesokurtic(dref)

            @test entropy(dtest) ≈ entropy(dref)
            @test mgf(dtest,-0.1) ≈ mgf(dref,-0.1)
        end
    end

    #### Evaluation & Sampling

    @testset "Evaluation & Sampling" begin
        @testset "$k" for (k,dtest) in d_dict
            xs = rand(dref, 5)
            x = first(xs)
            insupport(dtest, x) == insupport(dref, x)
            # might return `false` for discrete distributions
            insupport(dtest, -x) == insupport(dref, -x)

            @test pdf(dtest, x) ≈ pdf(dref, x)
            @test Base.Fix1(pdf, dtest).(xs) ≈ Base.Fix1(pdf, dref).(xs)
            @test logpdf(dtest, x) ≈ logpdf(dref, x)
            @test Base.Fix1(logpdf, dtest).(xs) ≈ Base.Fix1(logpdf, dref).(xs)
            @test loglikelihood(dtest, x) ≈ loglikelihood(dref, x)
            @test loglikelihood(dtest, xs) ≈ loglikelihood(dref, xs)

            @test cdf(dtest, x) ≈ cdf(dref, x)
            @test logcdf(dtest, x) ≈ logcdf(dref, x) atol=1e-14
            @test ccdf(dtest, x) ≈ ccdf(dref, x) atol=1e-14
            @test logccdf(dtest, x) ≈ logccdf(dref, x) atol=1e-14

            @test quantile(dtest, 0.1) ≈ quantile(dref, 0.1)
            @test quantile(dtest, 0.5) ≈ quantile(dref, 0.5)
            @test quantile(dtest, 0.9) ≈ quantile(dref, 0.9)

            @test cquantile(dtest, 0.1) ≈ cquantile(dref, 0.1)
            @test cquantile(dtest, 0.5) ≈ cquantile(dref, 0.5)
            @test cquantile(dtest, 0.9) ≈ cquantile(dref, 0.9)

            @test invlogcdf(dtest, log(0.2)) ≈ invlogcdf(dref, log(0.2))
            @test invlogcdf(dtest, log(0.5)) ≈ invlogcdf(dref, log(0.5))
            @test invlogcdf(dtest, log(0.8)) ≈ invlogcdf(dref, log(0.8))

            @test invlogccdf(dtest, log(0.2)) ≈ invlogccdf(dref, log(0.2))
            @test invlogccdf(dtest, log(0.5)) ≈ invlogccdf(dref, log(0.5))
            @test invlogccdf(dtest, log(0.8)) ≈ invlogccdf(dref, log(0.8))

            r = Array{float(eltype(dtest))}(undef, 200000)
            if ismissing(rng)
                rand!(dtest, r)
            else
                rand!(rng, dtest, r)
            end
            @test mean(r) ≈ mean(dref) atol=0.02
            @test std(r) ≈ std(dref) atol=0.02
            @test cf(dtest, -0.1) ≈ cf(dref,-0.1)

            if dref isa ContinuousDistribution
                @test gradlogpdf(dtest, 0.1) ≈ gradlogpdf(dref, 0.1)
            end
        end
    end
end

function test_location_scale_normal(
    rng::Union{AbstractRNG, Missing}, μ::Real, σ::Real, μD::Real, σD::Real,
)
    ρ = Normal(μD, σD)
    dref = Normal(μ + σ * μD,  abs(σ) * σD)
    @test dref === μ + σ * ρ
    return test_location_scale(rng, μ, σ, ρ, dref)
end

function test_location_scale_discretenonparametric(
    rng::Union{AbstractRNG, Missing}, μ::Real, σ::Real, support, probs,
)
    ρ = DiscreteNonParametric(support, probs)
    dref = DiscreteNonParametric(μ .+ σ .* support, probs)
    return test_location_scale(rng, μ, σ, ρ, dref)
end

@testset "AffineDistribution" begin
    rng = MersenneTwister(123)

    @testset "Normal" begin
        @testset for _rng in (missing, rng), sign in (1, -1)
            test_location_scale_normal(_rng, 0.3, sign * 0.2, 0.1, 0.2)
            test_location_scale_normal(_rng, -0.3, sign * 0.1, -0.1, 0.3)
            test_location_scale_normal(_rng, 1.3, sign * 0.4, -0.1, 0.5)
        end
        test_location_scale_normal(rng, ForwardDiff.Dual(0.3), 0.2, 0.1, 0.2)
    end
    @testset "DiscreteNonParametric" begin
        _probs = normalize!(rand(10), 1)
        @testset for _rng in (missing, rng), sign in (1, -1)
            test_location_scale_discretenonparametric(_rng, 1//3, sign * 1//2, 1:10, _probs)
            test_location_scale_discretenonparametric(_rng, -1//4, sign * 1//3, (-10):(-1), _probs)
            test_location_scale_discretenonparametric(_rng, 6//5, sign * 3//2, 15:24, _probs)
        end
    end

    @test_logs Distributions.AffineDistribution(1.0, 1, Normal())

    @test_deprecated ls_norm = LocationScale(1.0, 1, Normal())
    @test ls_norm isa LocationScale{Float64, Continuous, Normal{Float64}}
    @test ls_norm isa Distributions.AffineDistribution{Float64, Continuous, Normal{Float64}}
end

# Injected from runtests.jl
using Distributions
using PDMats # test dependencies
using Test
using Distributed
using Random
using SpecialFunctions
using StatsBase
using LinearAlgebra

import JSON
import ForwardDiff

const tests = [
    "aqua",
    "univariate/continuous/loguniform",
    "univariate/continuous/arcsine",
    "univariate/discrete/dirac",
    "truncate",
    "truncated/normal",
    "truncated/exponential",
    "truncated/uniform",
    "truncated/discrete_uniform",
    "censored",
    "univariate/continuous/normal",
    "univariate/continuous/normalcanon",
    "univariate/continuous/laplace",
    "univariate/continuous/cauchy",
    "univariate/continuous/uniform",
    "univariate/continuous/lognormal",
    "multivariate/mvnormal",
    "multivariate/mvlogitnormal",
    "multivariate/mvlognormal",
    "types", # extra file compared to /src
    "utils",
    "samplers",
    "univariate/discrete/categorical",
    "univariates",
    "univariate/continuous", # extra file compared to /src
    "edgecases", # extra file compared to /src
    "fit", # extra file compared to /src
    "multivariate/multinomial",
    "univariate/discrete/binomial",
    "univariate/discrete/betabinomial",
    "univariate/discrete/poissonbinomial",
    "multivariate/dirichlet",
    "multivariate/dirichletmultinomial",
    "univariate/continuous/logitnormal",
    "multivariate/mvtdist",
    "univariate/continuous/kolmogorov",
    "edgeworth",
    "matrixreshaped", # extra file compared to /src
    "matrixvariates",
    "cholesky/lkjcholesky",
    "multivariate/vonmisesfisher",
    "conversion",
    "convolution",
    "mixture", # extra file compared to /src
    "gradlogpdf", # extra file compared to /src
    "univariate/continuous/noncentralt",
    "univariate/locationscale",
    "quantile_newton", # extra file compared to /src
    "univariate/continuous/semicircle",
    "qq",
    "univariate/continuous/pgeneralizedgaussian",
    "product",
    "namedtuple/productnamedtuple",
    "univariate/discrete/discretenonparametric",
    "univariate/continuous/chernoff",
    "univariate_bounds", # extra file compared to /src
    "univariate/discrete/negativebinomial",
    "univariate/discrete/geometric",
    "univariate/discrete/bernoulli",
    "univariate/discrete/poisson",
    "univariate/discrete/soliton",
    "univariate/continuous/skewnormal",
    "univariate/continuous/chi",
    "univariate/continuous/chisq",
    "univariate/continuous/erlang",
    "univariate/continuous/exponential",
    "univariate/continuous/gamma",
    "univariate/continuous/gumbel",
    "univariate/continuous/lindley",
    "univariate/continuous/logistic",
    "univariate/continuous/johnsonsu",
    "univariate/continuous/noncentralchisq",
    "univariate/continuous/weibull",
    "pdfnorm",
    "univariate/continuous/pareto",
    "univariate/continuous/rician",
    "functionals",
    "density_interface",
    "reshaped",
    "univariate/continuous/skewedexponentialpower",
    "univariate/discrete/discreteuniform",
    "univariate/continuous/tdist",
    "univariate/orderstatistic",
    "multivariate/jointorderstatistics",
    "multivariate/product",
    "eachvariate",
    "univariate/continuous/triangular",
    "statsapi",
    "univariate/continuous/inversegaussian",

    ### missing files compared to /src:
    # "common",
    # "estimators",
    # "genericfit",
    # "matrix/inversewishart",
    # "matrix/lkj",
    # "matrix/matrixbeta",
    # "matrix/matrixfdist",
    # "matrix/matrixnormal",
    # "matrix/matrixtdist",
    # "matrix/wishart",
    # "mixtures/mixturemodel",
    # "mixtures/unigmm",
    # "multivariate/mvnormalcanon",
    # "quantilealgs",
    # "samplers/aliastable",
    # "samplers/binomial",
    # "samplers/categorical",
    # "samplers/discretenonparametric",
    # "samplers/exponential",
    # "samplers/gamma",
    # "samplers/multinomial",
    # "samplers/obsoleted",
    # "samplers/poisson",
    # "samplers/poissonbinomial",
    # "samplers/vonmises",
    # "samplers/vonmisesfisher",
    # "show",
    # "truncated/loguniform",
    # "univariate/continuous/beta",
    # "univariate/continuous/beta",
    # "univariate/continuous/betaprime",
    # "univariate/continuous/biweight",
    # "univariate/continuous/cosine",
    # "univariate/continuous/epanechnikov",
    # "univariate/continuous/fdist",
    # "univariate/continuous/frechet",
    # "univariate/continuous/generalizedextremevalue",
    # "univariate/continuous/generalizedpareto",
    # "univariate/continuous/inversegamma",
    # "univariate/continuous/ksdist",
    # "univariate/continuous/ksonesided",
    # "univariate/continuous/levy",
    # "univariate/continuous/noncentralbeta",
    # "univariate/continuous/noncentralf",
    # "univariate/continuous/normalinversegaussian",
    # "univariate/continuous/rayleigh",
    # "univariate/continuous/studentizedrange",
    # "univariate/continuous/symtriangular",
    # "univariate/continuous/tdist",
    # "univariate/continuous/triweight",
    # "univariate/continuous/noncentralf",
    # "univariate/discrete/geometric",
    # "univariate/discrete/hypergeometric",
    # "univariate/discrete/noncentralhypergeometric",
    # "univariate/discrete/poisson",
    # "univariate/discrete/skellam",

    ### file is present but was not included in list
    # "multivariate_stats", # extra file compared to /src
    # "univariate/continuous/vonmises",
]

printstyled("Running tests:\n", color=:blue)

Random.seed!(345679)

# to reduce redundancy, we might break this file down into separate `$t * "_utils.jl"` files
include("testutils.jl")

using Distributions, PDMats
using Test, LinearAlgebra
import Distributions: ispossemdef

# RealInterval
r = RealInterval(1.5, 4.0)
@test minimum(r) == 1.5
@test maximum(r) == 4.0
@test extrema(r) == (1.5, 4.0)

@test partype(Gamma(1, 2)) == Float64
@test partype(Gamma(1.1, 2)) == Float64
@test partype(Normal(1//1, 2//1)) == Rational{Int}
@test partype(MvNormal(rand(Float32, 5), Matrix{Float32}(I, 5, 5))) == Float32

# special cases
@test partype(Kolmogorov()) == Float64
@test partype(Hypergeometric(2, 2, 2)) == Int
@test partype(Hypergeometric(2.0, 2, 2)) == Int
@test partype(DiscreteUniform(0, 4)) == Int
@test partype(DiscreteUniform(0.0, 4)) == Int

A = rand(1:10, 5, 5)
B = rand(Float32, 4)
C = 1//2
L = rand(Float32, 4, 4)
D = PDMats.PDMat(L * L')

# Ensure that utilities functions works with abstract arrays

@test isprobvec(GenericArray([1, 1, 1])) == false
@test isprobvec(GenericArray([1/3, 1/3, 1/3]))

# Positive definite matrix
M = GenericArray([1.0 0.0; 0.0 1.0])
# Non-invertible matrix
N = GenericArray([1.0 0.0; 1.0 0.0])

@test Distributions.isApproxSymmmetric(N) == false
@test Distributions.isApproxSymmmetric(M)


n = 10
areal = randn(n,n)/2
aimg  = randn(n,n)/2
@testset "For A containing $eltya" for eltya in (Float32, Float64, ComplexF32, ComplexF64, Int)
    ainit = eltya == Int ? rand(1:7, n, n) : convert(Matrix{eltya}, eltya <: Complex ? complex.(areal, aimg) : areal)
    @testset "Positive semi-definiteness" begin
        notsymmetric = ainit
        notsquare    = [ainit ainit]
        @test !ispossemdef(notsymmetric)
        @test !ispossemdef(notsquare)
        for truerank in 0:n
            X = ainit[:, 1:truerank]
            A = truerank == 0 ? zeros(eltya, n, n) : X * X'
            @test ispossemdef(A)
            for testrank in 0:n
                if testrank == truerank
                    @test ispossemdef(A, testrank)
                else
                    @test !ispossemdef(A, testrank)
                end
            end
            @test !ispossemdef(notsymmetric, truerank)
            @test !ispossemdef(notsquare, truerank)
            @test_throws ArgumentError ispossemdef(A, -1)
            @test_throws ArgumentError ispossemdef(A, n + 1)
        end
    end
end

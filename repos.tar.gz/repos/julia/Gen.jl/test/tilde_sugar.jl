# Injected from runtests.jl
using Gen
using Test
import Random
import Distributions

"""
Compute a numerical partial derivative of `f` with respect to the `i`th
argument using finite differences.

If `broadcast` is `false`, then `args[i]` must be a scalar.

If `broadcast` is `true`, then `args[i]` may be an array.  In that case, `f` is
assumed to be the broadcast of a function whose `i`th argument is a scalar.  In
particular, `f` must still operate independently on each element of `args[i]`.
This condition cannot be checked automatically for arbitrary `f::Function`, so
the caller must guarantee it.
"""
function finite_diff(f::Function, args::Tuple, i::Int, dx::Float64;
                     broadcast=false)
    pos_args = Any[args...]
    neg_args = Any[args...]
    if broadcast
        pos_args[i] = copy(args[i]) .+ dx
        neg_args[i] = copy(args[i]) .- dx
        ans = (f(pos_args...) - f(neg_args...)) ./ (2. * dx)
        # Workaround for
        # https://github.com/probcomp/Gen.jl/pull/433#discussion_r669958584
        if args[i] isa AbstractArray && ndims(args[i]) == 0
            return fill(ans)
        end
        return ans
    else
        pos_args[i] += dx
        neg_args[i] -= dx
        return (f(pos_args...) - f(neg_args...)) / (2. * dx)
    end
end

function finite_diff_vec(f::Function, args::Tuple, i::Int, j::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to the `i`th argument, a symettric matrix, using finite differences.

Finite differences are applied symettrically to off-diagonal elements of the matrix, ensuring that the modified matrix is still symettric.

When applied to off-diagonal elements, the finite difference is scaled by a factor of 1/2.

The condition that the `i`th argument is a symettric matrix cannot be checked automatically, so the caller must guarantee it.
"""

function finite_diff_mat_sym(f::Function, args::Tuple, i::Int, j::Int, k::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j, k] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j, k] -= dx

    if j!=k
        pos_args[i][k, j] += dx
        neg_args[i][k, j] -= dx
        return (f(pos_args...) - f(neg_args...)) / (4. * dx)
    end

    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to `idx`th element in the `i`th
argument, which must be array-valued, using finite differences.
"""
function finite_diff_arr(f::Function, args::Tuple, i::Int, idx, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][idx] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][idx] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Returns the partial derivatives of `f` with respect to all entries of
`args[i]`.

That is, returns an array of the same shape as `args[i]`, each entry of which
is [`finite_diff_arr`](@ref) applied to the corresponding entry of `args[i]`.

Requires that `args[i]` have nonzero rank.  Due to [1], handling
zero-dimensional arrays properly in this function is not feasible; the caller
should handle that case on their own.

[1] https://github.com/JuliaLang/julia/issues/28866
"""
function finite_diff_arr_fullarg(f::Function, args::Tuple, i::Int, dx::Float64)
    @assert args[i] isa AbstractArray
    @assert ndims(args[i]) > 0
    return [finite_diff_arr(f, args, i, idx, dx)
            for idx in keys(args[i])]
end

const dx = 1e-6

using Gen
import MacroTools

@testset "tilde syntax" begin

normalize(ex) = MacroTools.prewalk(MacroTools.rmlines, ex)

@testset "tilde syntax smoke test (dynamic)" begin
    @gen function foo(a, b)
        p ~ beta(a, b)
        return ({:coin => 1} ~ bernoulli(p)) + ({:coin => 2} ~ bernoulli(p))
    end

    trace = simulate(foo, (1, 1))
    @test (trace[:coin => 1] + trace[:coin => 2]) == get_retval(trace)
    @test get_score(trace) == sum([(trace[:coin => i] ? log(trace[:p]) : log(1-trace[:p])) for i=1:2])
end

@testset "tilde syntax smoke test (static)" begin
    @gen (static) function bar(r)
        a ~ normal(0, 1)
        return r
    end

    @gen (static) function foo()
        x ~ bar(1)
        yz = {:y => :z} ~ bar(2)
        u ~ normal(0, 1)
        {:v => :w} ~ normal(0, 1)
        retrate = 7
        return {:ret} ~ poisson(retrate)
    end

    trace = simulate(foo, ())

    # random choices
    @test trace[:u] isa Float64
    @test trace[:v => :w] isa Float64
    @test trace[:x => :a] isa Float64
    @test trace[:y => :z => :a] isa Float64

    # auxiliary state
    @test trace[:x] == 1
    @test trace[:y => :z] == 2

    # return value
    @test trace[] == trace[:ret]
end

@testset "tilde syntax desugars as expected (static)" begin
    expected = normalize(Gen.preprocess_body(:(
    begin
        x = @trace(normal(0, 1), :x)
        y = @trace(normal(0, 1), :y)
    end), Main))

    actual = normalize(Gen.desugar_tildes(:(
    begin
        x ~ normal(0, 1)
        y = ({:y} ~ normal(0, 1))
    end)))

    @test actual == expected
end

@testset "tilde syntax preserved in quoted expressions" begin
    @gen function tilde_expr()
        return :(x ~ normal(0, 1))
    end
    @test tilde_expr() == :(x ~ normal(0, 1))

    @gen (static) function tilde_expr()
        return :(x ~ normal(0, 1))
    end
    @test tilde_expr() == :(x ~ normal(0, 1))
end

end

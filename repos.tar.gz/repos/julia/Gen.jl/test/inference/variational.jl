# Injected from runtests.jl
using Gen
using Test
import Random
import Distributions

"""
Compute a numerical partial derivative of `f` with respect to the `i`th
argument using finite differences.

If `broadcast` is `false`, then `args[i]` must be a scalar.

If `broadcast` is `true`, then `args[i]` may be an array.  In that case, `f` is
assumed to be the broadcast of a function whose `i`th argument is a scalar.  In
particular, `f` must still operate independently on each element of `args[i]`.
This condition cannot be checked automatically for arbitrary `f::Function`, so
the caller must guarantee it.
"""
function finite_diff(f::Function, args::Tuple, i::Int, dx::Float64;
                     broadcast=false)
    pos_args = Any[args...]
    neg_args = Any[args...]
    if broadcast
        pos_args[i] = copy(args[i]) .+ dx
        neg_args[i] = copy(args[i]) .- dx
        ans = (f(pos_args...) - f(neg_args...)) ./ (2. * dx)
        # Workaround for
        # https://github.com/probcomp/Gen.jl/pull/433#discussion_r669958584
        if args[i] isa AbstractArray && ndims(args[i]) == 0
            return fill(ans)
        end
        return ans
    else
        pos_args[i] += dx
        neg_args[i] -= dx
        return (f(pos_args...) - f(neg_args...)) / (2. * dx)
    end
end

function finite_diff_vec(f::Function, args::Tuple, i::Int, j::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to the `i`th argument, a symettric matrix, using finite differences.

Finite differences are applied symettrically to off-diagonal elements of the matrix, ensuring that the modified matrix is still symettric.

When applied to off-diagonal elements, the finite difference is scaled by a factor of 1/2.

The condition that the `i`th argument is a symettric matrix cannot be checked automatically, so the caller must guarantee it.
"""

function finite_diff_mat_sym(f::Function, args::Tuple, i::Int, j::Int, k::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j, k] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j, k] -= dx

    if j!=k
        pos_args[i][k, j] += dx
        neg_args[i][k, j] -= dx
        return (f(pos_args...) - f(neg_args...)) / (4. * dx)
    end

    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to `idx`th element in the `i`th
argument, which must be array-valued, using finite differences.
"""
function finite_diff_arr(f::Function, args::Tuple, i::Int, idx, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][idx] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][idx] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Returns the partial derivatives of `f` with respect to all entries of
`args[i]`.

That is, returns an array of the same shape as `args[i]`, each entry of which
is [`finite_diff_arr`](@ref) applied to the corresponding entry of `args[i]`.

Requires that `args[i]` have nonzero rank.  Due to [1], handling
zero-dimensional arrays properly in this function is not feasible; the caller
should handle that case on their own.

[1] https://github.com/JuliaLang/julia/issues/28866
"""
function finite_diff_arr_fullarg(f::Function, args::Tuple, i::Int, dx::Float64)
    @assert args[i] isa AbstractArray
    @assert ndims(args[i]) > 0
    return [finite_diff_arr(f, args, i, idx, dx)
            for idx in keys(args[i])]
end

const dx = 1e-6

@testset "black box variational inference" begin

    Random.seed!(1)

    @gen function model()
        slope = @trace(normal(-1, exp(0.5)), :slope)
        intercept = @trace(normal(1, exp(2.0)), :intercept)
    end

    @gen function approx()
        @param slope_mu::Float64
        @param slope_log_std::Float64
        @param intercept_mu::Float64
        @param intercept_log_std::Float64
        @trace(normal(slope_mu, exp(slope_log_std)), :slope)
        @trace(normal(intercept_mu, exp(intercept_log_std)), :intercept)
    end

    # to regular black box variational inference
    init_param!(approx, :slope_mu, 0.)
    init_param!(approx, :slope_log_std, 0.)
    init_param!(approx, :intercept_mu, 0.)
    init_param!(approx, :intercept_log_std, 0.)

    observations = choicemap()
    update = ParamUpdate(GradientDescent(1, 100000), approx)
    update = ParamUpdate(GradientDescent(1., 1000), approx)
    black_box_vi!(model, (), observations, approx, (), update;
        iters=2000, samples_per_iter=100, verbose=false)
    slope_mu = get_param(approx, :slope_mu)
    slope_log_std = get_param(approx, :slope_log_std)
    intercept_mu = get_param(approx, :intercept_mu)
    intercept_log_std = get_param(approx, :intercept_log_std)
    @test isapprox(slope_mu, -1., atol=0.001)
    @test isapprox(slope_log_std, 0.5, atol=0.001)
    @test isapprox(intercept_mu, 1., atol=0.001)
    @test isapprox(intercept_log_std, 2.0, atol=0.001)

    # smoke test for black box variational inference with Monte Carlo objectives
    init_param!(approx, :slope_mu, 0.)
    init_param!(approx, :slope_log_std, 0.)
    init_param!(approx, :intercept_mu, 0.)
    init_param!(approx, :intercept_log_std, 0.)
    black_box_vimco!(model, (), observations, approx, (), update, 20;
        iters=50, samples_per_iter=100, verbose=false, geometric=false)

    init_param!(approx, :slope_mu, 0.)
    init_param!(approx, :slope_log_std, 0.)
    init_param!(approx, :intercept_mu, 0.)
    init_param!(approx, :intercept_log_std, 0.)
    black_box_vimco!(model, (), observations, approx, (), update, 20;
        iters=50, samples_per_iter=100, verbose=false, geometric=true)

end

@testset "minimal vae" begin

    Random.seed!(1)

    n = 10

    @gen function model()
        @param theta::Float64
        for i in 1:n
            z = ({(:z, i)} ~ normal(theta, 1))
            {(:x, i)} ~ normal(z, 1)
        end
    end

    @gen function approx(xs)
        @param mu_coeffs::Vector{Float64} # 2 x 1; should be [opt_theta / 2, 0.5]
        @param log_std::Float64
        for i in 1:n
            mu = mu_coeffs[1] + mu_coeffs[2] * xs[i]
            {(:z, i)} ~ normal(mu, exp(log_std))
        end
    end

    observations = choicemap()
    xs = Float64[]
    for i in 1:n
        z = normal(-1.0, 1)
        x = normal(z, 1)
        push!(xs, x)
        observations[(:x, i)] = x
    end

    # the optimum maximum marginal likelihood is at theta = mean(xs)
    opt_theta = sum(xs) / length(xs)
    println("opt_theta: $opt_theta")
    # see https://www.cs.ubc.ca/~murphyk/Papers/bayesGauss.pdf
    posterior_precisions = 1.0 + 1 * 1.0 # n = 1
    posterior_means = (xs .+ opt_theta) ./ 2.0
    posterior_precisions = 2.0
    @gen function optimum_approx()
        for i in 1:n
            {(:z, i)} ~ normal(posterior_means[i], sqrt(1.0 / posterior_precisions))
        end
    end
    init_param!(model, :theta, opt_theta)
    approx_trace = simulate(optimum_approx, ())
    (model_trace, _) = generate(model, (), merge(get_choices(approx_trace), observations))
    # note that p(z1..zn, x1..xn) / p(z1..zn | x1..xn) = p(x1...xn) - for all z1..zn
    log_marginal_likelihood = get_score(model_trace) - get_score(approx_trace)
    println("true optimum log_marginal_likelihood: $log_marginal_likelihood")

    # using BBVI with score function estimator
    init_param!(model, :theta, 0.0)
    init_param!(approx, :mu_coeffs, zeros(2))
    init_param!(approx, :log_std, 0.0)
    approx_update = ParamUpdate(FixedStepGradientDescent(0.0001), approx)
    model_update = ParamUpdate(FixedStepGradientDescent(0.002), model)
    @time (_, _, elbo_history, _) =
        black_box_vi!(model, (), model_update, observations,
                      approx, (xs,), approx_update;
                      iters=3000, samples_per_iter=20, verbose=false)
    @test isapprox(get_param(model, :theta), opt_theta, atol=1e-1)
    println("final theta: $(get_param(model, :theta))")
    println("final elbo estimate: $(elbo_history[end])")
    @test isapprox(elbo_history[end], log_marginal_likelihood, rtol=0.1)

    # using VIMCO
    init_param!(model, :theta, 0.0)
    init_param!(approx, :mu_coeffs, zeros(2))
    init_param!(approx, :log_std, 0.0)
    approx_update = ParamUpdate(FixedStepGradientDescent(0.001), approx)
    model_update = ParamUpdate(FixedStepGradientDescent(0.01), model)
    @time (_, _, elbo_history, _) =
        black_box_vimco!(model, (), model_update, observations,
                         approx, (xs,), approx_update, 10;
                         iters=1000, samples_per_iter=10, verbose=false)
    println("final theta: $(get_param(model, :theta))")
    println("final elbo estimate: $(elbo_history[end])")
    @test isapprox(elbo_history[end], log_marginal_likelihood, rtol=0.1)
end

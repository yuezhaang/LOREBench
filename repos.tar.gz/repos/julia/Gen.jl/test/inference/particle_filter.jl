# Injected from runtests.jl
using Gen
using Test
import Random
import Distributions

"""
Compute a numerical partial derivative of `f` with respect to the `i`th
argument using finite differences.

If `broadcast` is `false`, then `args[i]` must be a scalar.

If `broadcast` is `true`, then `args[i]` may be an array.  In that case, `f` is
assumed to be the broadcast of a function whose `i`th argument is a scalar.  In
particular, `f` must still operate independently on each element of `args[i]`.
This condition cannot be checked automatically for arbitrary `f::Function`, so
the caller must guarantee it.
"""
function finite_diff(f::Function, args::Tuple, i::Int, dx::Float64;
                     broadcast=false)
    pos_args = Any[args...]
    neg_args = Any[args...]
    if broadcast
        pos_args[i] = copy(args[i]) .+ dx
        neg_args[i] = copy(args[i]) .- dx
        ans = (f(pos_args...) - f(neg_args...)) ./ (2. * dx)
        # Workaround for
        # https://github.com/probcomp/Gen.jl/pull/433#discussion_r669958584
        if args[i] isa AbstractArray && ndims(args[i]) == 0
            return fill(ans)
        end
        return ans
    else
        pos_args[i] += dx
        neg_args[i] -= dx
        return (f(pos_args...) - f(neg_args...)) / (2. * dx)
    end
end

function finite_diff_vec(f::Function, args::Tuple, i::Int, j::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to the `i`th argument, a symettric matrix, using finite differences.

Finite differences are applied symettrically to off-diagonal elements of the matrix, ensuring that the modified matrix is still symettric.

When applied to off-diagonal elements, the finite difference is scaled by a factor of 1/2.

The condition that the `i`th argument is a symettric matrix cannot be checked automatically, so the caller must guarantee it.
"""

function finite_diff_mat_sym(f::Function, args::Tuple, i::Int, j::Int, k::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j, k] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j, k] -= dx

    if j!=k
        pos_args[i][k, j] += dx
        neg_args[i][k, j] -= dx
        return (f(pos_args...) - f(neg_args...)) / (4. * dx)
    end

    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to `idx`th element in the `i`th
argument, which must be array-valued, using finite differences.
"""
function finite_diff_arr(f::Function, args::Tuple, i::Int, idx, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][idx] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][idx] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Returns the partial derivatives of `f` with respect to all entries of
`args[i]`.

That is, returns an array of the same shape as `args[i]`, each entry of which
is [`finite_diff_arr`](@ref) applied to the corresponding entry of `args[i]`.

Requires that `args[i]` have nonzero rank.  Due to [1], handling
zero-dimensional arrays properly in this function is not feasible; the caller
should handle that case on their own.

[1] https://github.com/JuliaLang/julia/issues/28866
"""
function finite_diff_arr_fullarg(f::Function, args::Tuple, i::Int, dx::Float64)
    @assert args[i] isa AbstractArray
    @assert ndims(args[i]) > 0
    return [finite_diff_arr(f, args, i, idx, dx)
            for idx in keys(args[i])]
end

const dx = 1e-6

function hmm_forward_alg(prior::Vector{Float64},
        emission_dists::AbstractArray{Float64,2}, transition_dists::AbstractArray{Float64,2},
        emissions::Vector{Int})
    marg_lik = 1.
    alpha = prior # p(z_1)
    for i=2:length(emissions)

        # p(z_{i-1} , y_{i-1} | y_{1:i-2}) for each z_{i-1}
        prev_posterior = alpha .* emission_dists[emissions[i-1], :]

        # p(y_{i-1} | y_{1:i-2})
        denom = sum(prev_posterior)

        # p(z_{i-1} | y_{1:i-1})
        prev_posterior = prev_posterior / denom

        # p(z_i | y_{1:i-1})
        alpha = transition_dists * prev_posterior

        # p(y_{1:i-1})
        marg_lik *= denom
    end
    prev_posterior = alpha .* emission_dists[emissions[end], :]
    denom = sum(prev_posterior)
    marg_lik *= denom
    marg_lik
end

@testset "hmm forward alg" begin

    # test the hmm_forward_alg on a hand-calculated example
    prior = [0.4, 0.6]
    emission_dists = [0.1 0.9; 0.7 0.3]'
    transition_dists = [0.5 0.5; 0.2 0.8]'
    obs = [2, 1]
    expected_marg_lik = 0.
    # z = [1, 1]
    expected_marg_lik += prior[1] * transition_dists[1, 1] * emission_dists[obs[1], 1] * emission_dists[obs[2], 1]
    # z = [1, 2]
    expected_marg_lik += prior[1] * transition_dists[2, 1] * emission_dists[obs[1], 1] * emission_dists[obs[2], 2]
    # z = [2, 1]
    expected_marg_lik += prior[2] * transition_dists[1, 2] * emission_dists[obs[1], 2] * emission_dists[obs[2], 1]
    # z = [2, 2]
    expected_marg_lik += prior[2] * transition_dists[2, 2] * emission_dists[obs[1], 2] * emission_dists[obs[2], 2]
    actual_marg_lik = hmm_forward_alg(prior, emission_dists, transition_dists, obs)
    @test isapprox(actual_marg_lik, expected_marg_lik)

end

@testset "particle filtering" begin

    prior = [0.2, 0.3, 0.5]

    emission_dists = [
        0.1 0.2 0.7;
        0.2 0.7 0.1;
        0.7 0.2 0.1
    ]'

    transition_dists = [
        0.4 0.4 0.2;
        0.2 0.3 0.5;
        0.9 0.05 0.05
    ]'

    @gen function kernel(t::Int, prev_z::Int, params::Nothing)
        z = @trace(categorical(transition_dists[:,prev_z]), :z)
        @trace(categorical(emission_dists[:,z]), :x)
        return z
    end

    chain = Unfold(kernel)

    @gen function model(num_steps::Int)
        z_init = @trace(categorical(prior), :z_init)
        @trace(categorical(emission_dists[:,z_init]), :x_init)
        @trace(chain(num_steps-1, z_init, nothing), :chain)
    end

    num_steps = 4
    obs_x = [1, 1, 2, 3]

    # latents:
    # :z_init
    # :chain => 1 => :z
    # :chain => 2 => :z
    # :chain => 3 => :z

    # observations :
    # :x_init
    # :chain => 1 => :x
    # :chain => 2 => :x
    # :chain => 3 => :x


@testset "custom proposal" begin

    Random.seed!(1)
    num_particles = 20000
    ess_threshold = 20000 # make sure we exercise resampling

    # initialize particle filter

    @gen function init_proposal(x::Int)
        dist = prior .* emission_dists[x,:]
        @trace(categorical(dist ./ sum(dist)), :z_init)
    end

    init_proposal_args = (obs_x[1],)
    init_observations = choicemap((:x_init, obs_x[1]))

    state = initialize_particle_filter(model, (1,), init_observations,
        init_proposal, init_proposal_args, num_particles)

    # do particle filter steps

    @gen function step_proposal(prev_trace, T::Int, x::Int)
        @assert T > 1
        choices = get_choices(prev_trace)
        if T > 2
            prev_z = choices[:chain => (T-2) => :z]
        else
            prev_z = choices[:z_init]
        end
        dist = transition_dists[:,prev_z] .* emission_dists[x,:]
        @trace(categorical(dist ./ sum(dist)), :chain => T-1 => :z)
    end

    argdiffs = (UnknownChange(),) # the length may change
    for T=2:length(obs_x)
        maybe_resample!(state, ess_threshold=ess_threshold)
        new_args = (T,)
        observations = choicemap((:chain => (T-1) => :x, obs_x[T]))
        proposal_args = (T, obs_x[T])
        log_incremental_weights, = particle_filter_step!(state, new_args, argdiffs, observations,
            step_proposal, proposal_args)
        @test length(log_incremental_weights) == num_particles
    end

    # check log marginal likelihood estimate
    expected_log_ml = log(hmm_forward_alg(prior, emission_dists, transition_dists, obs_x))
    actual_log_ml_est = log_ml_estimate(state)
    @test isapprox(expected_log_ml, actual_log_ml_est, atol=0.02)
end

@testset "default proposal" begin

    Random.seed!(1)
    num_particles = 20000
    ess_threshold = 20000 # make sure we exercise resampling

    # initialize the particle filter
    init_observations = choicemap((:x_init, obs_x[1]))
    state = initialize_particle_filter(model, (1,), init_observations, num_particles)

    # do steps
    argdiffs = (UnknownChange(),) # the length may change
    for T=2:length(obs_x)
        maybe_resample!(state, ess_threshold=ess_threshold)
        new_args = (T,)
        observations = choicemap((:chain => (T-1) => :x, obs_x[T]))
        log_incremental_weights, = particle_filter_step!(state, new_args, argdiffs, observations)
        @test length(log_incremental_weights) == num_particles
    end

    # check log marginal likelihood estimate
    expected_log_ml = log(hmm_forward_alg(prior, emission_dists, transition_dists, obs_x))
    actual_log_ml_est = log_ml_estimate(state)
    @test isapprox(expected_log_ml, actual_log_ml_est, atol=0.02)
end

@testset "PF state" begin
    @gen function _foo()
        x ~ normal(0, 1)
    end
    st = Gen.ParticleFilterState{Gen.Trace}(
        [simulate(_foo, ()) for _=1:10],
        Vector{Gen.Trace}(undef, 10),
        [0. for _=1:10],
        0.,
        collect(1:10)
    )
    st2 = copy(st)
    @test st == st2
    @test hash(st) == hash(st2)
    st2.log_weights[1] = 1.
    @test st.log_weights[1] == 0.
    @test st != st2
    @test hash(st) != hash(st2)

    # test that the other fields are independent copies too:
    st.traces[1] = simulate(_foo, ())
    @test st.traces != st2.traces
    st.log_ml_est = 1.
    @test st.log_ml_est == 1.
    st.parents[1] = 5
    @test st2.parents[1] == 1
end
end
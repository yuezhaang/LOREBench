# Injected from runtests.jl
using Gen
using Test
import Random
import Distributions

"""
Compute a numerical partial derivative of `f` with respect to the `i`th
argument using finite differences.

If `broadcast` is `false`, then `args[i]` must be a scalar.

If `broadcast` is `true`, then `args[i]` may be an array.  In that case, `f` is
assumed to be the broadcast of a function whose `i`th argument is a scalar.  In
particular, `f` must still operate independently on each element of `args[i]`.
This condition cannot be checked automatically for arbitrary `f::Function`, so
the caller must guarantee it.
"""
function finite_diff(f::Function, args::Tuple, i::Int, dx::Float64;
                     broadcast=false)
    pos_args = Any[args...]
    neg_args = Any[args...]
    if broadcast
        pos_args[i] = copy(args[i]) .+ dx
        neg_args[i] = copy(args[i]) .- dx
        ans = (f(pos_args...) - f(neg_args...)) ./ (2. * dx)
        # Workaround for
        # https://github.com/probcomp/Gen.jl/pull/433#discussion_r669958584
        if args[i] isa AbstractArray && ndims(args[i]) == 0
            return fill(ans)
        end
        return ans
    else
        pos_args[i] += dx
        neg_args[i] -= dx
        return (f(pos_args...) - f(neg_args...)) / (2. * dx)
    end
end

function finite_diff_vec(f::Function, args::Tuple, i::Int, j::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to the `i`th argument, a symettric matrix, using finite differences.

Finite differences are applied symettrically to off-diagonal elements of the matrix, ensuring that the modified matrix is still symettric.

When applied to off-diagonal elements, the finite difference is scaled by a factor of 1/2.

The condition that the `i`th argument is a symettric matrix cannot be checked automatically, so the caller must guarantee it.
"""

function finite_diff_mat_sym(f::Function, args::Tuple, i::Int, j::Int, k::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j, k] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j, k] -= dx

    if j!=k
        pos_args[i][k, j] += dx
        neg_args[i][k, j] -= dx
        return (f(pos_args...) - f(neg_args...)) / (4. * dx)
    end

    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to `idx`th element in the `i`th
argument, which must be array-valued, using finite differences.
"""
function finite_diff_arr(f::Function, args::Tuple, i::Int, idx, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][idx] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][idx] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Returns the partial derivatives of `f` with respect to all entries of
`args[i]`.

That is, returns an array of the same shape as `args[i]`, each entry of which
is [`finite_diff_arr`](@ref) applied to the corresponding entry of `args[i]`.

Requires that `args[i]` have nonzero rank.  Due to [1], handling
zero-dimensional arrays properly in this function is not feasible; the caller
should handle that case on their own.

[1] https://github.com/JuliaLang/julia/issues/28866
"""
function finite_diff_arr_fullarg(f::Function, args::Tuple, i::Int, dx::Float64)
    @assert args[i] isa AbstractArray
    @assert ndims(args[i]) > 0
    return [finite_diff_arr(f, args, i, idx, dx)
            for idx in keys(args[i])]
end

const dx = 1e-6

@testset "hmc tests" begin
    import LinearAlgebra, Random
    
    # smoke test a function without retval gradient
    @gen function foo()
        x = @trace(normal(0, 1), :x)
        return x
    end

    (trace, _) = generate(foo, ())
    (new_trace, accepted) = hmc(trace, select(:x))

    # smoke test a function with retval gradient
    @gen (grad) function foo()
        x = @trace(normal(0, 1), :x)
        return x
    end

    (trace, _) = generate(foo, ())
    (new_trace, accepted) = hmc(trace, select(:x))

    # For Normal(0,1), grad should be -x
    (_, value_choices, gradient_choices) = choice_gradients(trace, select(:x), 0)
    values = to_array(value_choices, Float64)
    grad = to_array(gradient_choices, Float64)
    @test values ≈ -grad

    # smoke test with vector metric
    @gen function bar()
        x = @trace(normal(0, 1), :x)
        y = @trace(normal(0, 1), :y)
        return x + y
    end

    (trace, _) = generate(bar, ())
    metric_vec = [1.0, 2.0]
    (new_trace, accepted) = hmc(trace, select(:x, :y); metric=metric_vec)

    # smoke test with Diagonal metric
    (trace, _) = generate(bar, ())
    metric_diag = LinearAlgebra.Diagonal([1.0, 2.0])
    (new_trace, accepted) = hmc(trace, select(:x, :y); metric=metric_diag)

    # smoke test with Dense matrix metric
    (trace, _) = generate(bar, ())
    metric_dense = [1.0 0.1; 0.1 2.0]
    (new_trace, accepted) = hmc(trace, select(:x, :y); metric=metric_dense)

    # smoke test with vector metric and retval gradient
    @gen (grad) function bar_grad()
        x = @trace(normal(0, 1), :x)
        y = @trace(normal(0, 1), :y)
        return x + y
    end

    (trace, _) = generate(bar_grad, ())
    metric_vec = [0.5, 1.5]
    (new_trace, accepted) = hmc(trace, select(:x, :y); metric=metric_vec)

    # For each Normal(0,1), grad should be -x
    (_, value_choices, gradient_choices) = choice_gradients(trace, select(:x, :y), 0)
    values = to_array(value_choices, Float64)
    grad = to_array(gradient_choices, Float64)
    @test values ≈ -grad

    # smoke test with Diagonal metric and retval gradient
    (trace, _) = generate(bar_grad, ())
    metric_diag = LinearAlgebra.Diagonal([0.5, 1.5])
    (new_trace, accepted) = hmc(trace, select(:x, :y); metric=metric_diag)

    # smoke test with Dense matrix metric and retval gradient
    (trace, _) = generate(bar_grad, ())
    metric_dense = [0.5 0.2; 0.2 1.5]
    (new_trace, accepted) = hmc(trace, select(:x, :y); metric=metric_dense)
end

@testset "hmc metric behavior" begin
    import LinearAlgebra, Random

    # test that different metrics produce different behavior
    @gen function test_metric_effect()
        x = @trace(normal(0, 1), :x)
        y = @trace(normal(0, 1), :y)
        return x + y
    end

    (trace1, _) = generate(test_metric_effect, ())
    

    # Set RNG to a known state for comparison
    Random.seed!(1)

    # Run HMC with identity metric (default)
    (trace_identity, _) = hmc(trace1, select(:x, :y); L=5)
    
    # Reset RNG to same state for comparison
    Random.seed!(1)
    
    # Run HMC with scaled metric (should behave differently)
    metric_scaled = [10.0, 0.1]  # Very different scales
    (trace_scaled, _) = hmc(trace1, select(:x, :y); L=5, metric=metric_scaled)
    
    # With same RNG sequence but different metrics, should get different results
    @test get_choices(trace_identity) != get_choices(trace_scaled)

    # With same metric but different representations, should get similar results
    # Test many times to check statistical similarity
    acceptances_diag = Float64[]
    acceptances_dense = Float64[]
    
    for i in 1:50
        # Reset to predictable state for each iteration
        Random.seed!(i)
        (_, accepted_diag) = hmc(trace1, select(:x, :y); 
                                metric=LinearAlgebra.Diagonal([2.0, 3.0]))
        
        # Reset to same state for comparison
        Random.seed!(i)
        (_, accepted_dense) = hmc(trace1, select(:x, :y); 
                                 metric=[2.0 0.0; 0.0 3.0])
        
        # Collect acceptance results
        push!(acceptances_diag, float(accepted_diag))
        push!(acceptances_dense, float(accepted_dense))
    end
    
    # # Should have similar acceptance rates (within 20%)
    rate_diag = Distributions.mean(acceptances_diag)
    rate_dense = Distributions.mean(acceptances_dense)
    @test abs(rate_diag - rate_dense) < 0.2


end

@testset "Bad metric catches" begin
    @gen function bar()
        x = @trace(normal(0, 1), :x)
        y = @trace(normal(0, 1), :y)
        return x + y
    end

    bad_metrics =([-1.0 -20.0; 0.0 1.0], # Bad dense,
                   LinearAlgebra.Diagonal([-1.0, -20.0]), # Bad diag
                   [-5.0, 20.0],  # Bad vector diag
    )

    for bad_metric in bad_metrics
        (trace, _) = generate(bar, ())
        @test_throws Exception hmc(trace, select(:x, :y); metric=bad_metric)
    end
    
end
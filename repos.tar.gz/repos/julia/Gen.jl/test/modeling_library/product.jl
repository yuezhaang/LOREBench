# Injected from runtests.jl
using Gen
using Test
import Random
import Distributions

"""
Compute a numerical partial derivative of `f` with respect to the `i`th
argument using finite differences.

If `broadcast` is `false`, then `args[i]` must be a scalar.

If `broadcast` is `true`, then `args[i]` may be an array.  In that case, `f` is
assumed to be the broadcast of a function whose `i`th argument is a scalar.  In
particular, `f` must still operate independently on each element of `args[i]`.
This condition cannot be checked automatically for arbitrary `f::Function`, so
the caller must guarantee it.
"""
function finite_diff(f::Function, args::Tuple, i::Int, dx::Float64;
                     broadcast=false)
    pos_args = Any[args...]
    neg_args = Any[args...]
    if broadcast
        pos_args[i] = copy(args[i]) .+ dx
        neg_args[i] = copy(args[i]) .- dx
        ans = (f(pos_args...) - f(neg_args...)) ./ (2. * dx)
        # Workaround for
        # https://github.com/probcomp/Gen.jl/pull/433#discussion_r669958584
        if args[i] isa AbstractArray && ndims(args[i]) == 0
            return fill(ans)
        end
        return ans
    else
        pos_args[i] += dx
        neg_args[i] -= dx
        return (f(pos_args...) - f(neg_args...)) / (2. * dx)
    end
end

function finite_diff_vec(f::Function, args::Tuple, i::Int, j::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to the `i`th argument, a symettric matrix, using finite differences.

Finite differences are applied symettrically to off-diagonal elements of the matrix, ensuring that the modified matrix is still symettric.

When applied to off-diagonal elements, the finite difference is scaled by a factor of 1/2.

The condition that the `i`th argument is a symettric matrix cannot be checked automatically, so the caller must guarantee it.
"""

function finite_diff_mat_sym(f::Function, args::Tuple, i::Int, j::Int, k::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j, k] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j, k] -= dx

    if j!=k
        pos_args[i][k, j] += dx
        neg_args[i][k, j] -= dx
        return (f(pos_args...) - f(neg_args...)) / (4. * dx)
    end

    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to `idx`th element in the `i`th
argument, which must be array-valued, using finite differences.
"""
function finite_diff_arr(f::Function, args::Tuple, i::Int, idx, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][idx] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][idx] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Returns the partial derivatives of `f` with respect to all entries of
`args[i]`.

That is, returns an array of the same shape as `args[i]`, each entry of which
is [`finite_diff_arr`](@ref) applied to the corresponding entry of `args[i]`.

Requires that `args[i]` have nonzero rank.  Due to [1], handling
zero-dimensional arrays properly in this function is not feasible; the caller
should handle that case on their own.

[1] https://github.com/JuliaLang/julia/issues/28866
"""
function finite_diff_arr_fullarg(f::Function, args::Tuple, i::Int, dx::Float64)
    @assert args[i] isa AbstractArray
    @assert ndims(args[i]) > 0
    return [finite_diff_arr(f, args, i, idx, dx)
            for idx in keys(args[i])]
end

const dx = 1e-6

discrete_product = ProductDistribution(bernoulli, binom)

@testset "product of discrete distributions" begin
    @test is_discrete(discrete_product)
    grad_bools = (has_output_grad(discrete_product), has_argument_grads(discrete_product)...)
    @test grad_bools == (false, true, false, true)

    p1 = 0.5
    (n, p2) = (3, 0.9)

    # random
    x = discrete_product(p1, n, p2)
    @assert typeof(x) == Gen.get_return_type(discrete_product) == Tuple{Bool, Int}

    # logpdf
    x = (true, 2)
    actual = logpdf(discrete_product, x, p1, n, p2)
    expected = logpdf(bernoulli, x[1], p1) + logpdf(binom, x[2], n, p2)
    @test isapprox(actual, expected)

    # test logpdf_grad against finite differencing
    f = (x, p1, n, p2) -> logpdf(discrete_product, x, p1, n, p2)
    args = (x, p1, n, p2)
    actual = logpdf_grad(discrete_product, args...)
    for i in [2, 4]
        @test isapprox(actual[i], finite_diff(f, args, i, dx))
    end
end

continuous_product = ProductDistribution(uniform, normal)

@testset "product of continuous distributions" begin
    @test !is_discrete(continuous_product)
    grad_bools = (has_output_grad(continuous_product), has_argument_grads(continuous_product)...)
    @test grad_bools == (true, true, true, true, true)

    (low, high) = (-0.5, 0.5)
    (mu, std) = (0.0, 1.0)

    # random
    x = continuous_product(low, high, mu, std)
    @assert typeof(x) == Gen.get_return_type(continuous_product) == Tuple{Float64, Float64}

    # logpdf
    x = (0.1, 0.7)
    actual = logpdf(continuous_product, x, low, high, mu, std)
    expected = logpdf(uniform, x[1], low, high) + logpdf(normal, x[2], mu, std)
    @test isapprox(actual, expected)

    # test logpdf_grad against finite differencing
    f = (x, low, high, mu, std) -> logpdf(continuous_product, x, low, high, mu, std)
    # A mutable indexable is required by `finite_diff_vec`, hence the `collect` here:
    args = (collect(x), low, high, mu, std)
    actual = logpdf_grad(continuous_product, args...)
    @test isapprox(actual[1][1], finite_diff_vec(f, args, 1, 1, dx))
    @test isapprox(actual[1][2], finite_diff_vec(f, args, 1, 2, dx))
    for i in 2:5
        @test isapprox(actual[i], finite_diff(f, args, i, dx))
    end
end

dissimilar_product = ProductDistribution(bernoulli, normal)

@testset "product of dissimilarly-typed distributions" begin
    @test !is_discrete(dissimilar_product)
    grad_bools = (has_output_grad(dissimilar_product), has_argument_grads(dissimilar_product)...)
    @test grad_bools == (false, true, true, true)

    p = 0.5
    (mu, std) = (0.0, 1.0)

    # random
    x = dissimilar_product(p, mu, std)
    @assert typeof(x) == Gen.get_return_type(dissimilar_product) == Tuple{Bool, Float64}

    # logpdf
    x = (false, 0.3)
    actual = logpdf(dissimilar_product, x, p, mu, std)
    expected = logpdf(bernoulli, x[1], p) + logpdf(normal, x[2], mu, std)
    @test isapprox(actual, expected)

    # test logpdf_grad against finite differencing
    f = (x, p, mu, std) -> logpdf(dissimilar_product, x, p, mu, std)
    args = (x, p, mu, std)
    actual = logpdf_grad(dissimilar_product, args...)
    for i in 2:4
        @test isapprox(actual[i], finite_diff(f, args, i, dx))
    end
end

# Injected from runtests.jl
using Gen
using Test
import Random
import Distributions

"""
Compute a numerical partial derivative of `f` with respect to the `i`th
argument using finite differences.

If `broadcast` is `false`, then `args[i]` must be a scalar.

If `broadcast` is `true`, then `args[i]` may be an array.  In that case, `f` is
assumed to be the broadcast of a function whose `i`th argument is a scalar.  In
particular, `f` must still operate independently on each element of `args[i]`.
This condition cannot be checked automatically for arbitrary `f::Function`, so
the caller must guarantee it.
"""
function finite_diff(f::Function, args::Tuple, i::Int, dx::Float64;
                     broadcast=false)
    pos_args = Any[args...]
    neg_args = Any[args...]
    if broadcast
        pos_args[i] = copy(args[i]) .+ dx
        neg_args[i] = copy(args[i]) .- dx
        ans = (f(pos_args...) - f(neg_args...)) ./ (2. * dx)
        # Workaround for
        # https://github.com/probcomp/Gen.jl/pull/433#discussion_r669958584
        if args[i] isa AbstractArray && ndims(args[i]) == 0
            return fill(ans)
        end
        return ans
    else
        pos_args[i] += dx
        neg_args[i] -= dx
        return (f(pos_args...) - f(neg_args...)) / (2. * dx)
    end
end

function finite_diff_vec(f::Function, args::Tuple, i::Int, j::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to the `i`th argument, a symettric matrix, using finite differences.

Finite differences are applied symettrically to off-diagonal elements of the matrix, ensuring that the modified matrix is still symettric.

When applied to off-diagonal elements, the finite difference is scaled by a factor of 1/2.

The condition that the `i`th argument is a symettric matrix cannot be checked automatically, so the caller must guarantee it.
"""

function finite_diff_mat_sym(f::Function, args::Tuple, i::Int, j::Int, k::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j, k] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j, k] -= dx

    if j!=k
        pos_args[i][k, j] += dx
        neg_args[i][k, j] -= dx
        return (f(pos_args...) - f(neg_args...)) / (4. * dx)
    end

    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to `idx`th element in the `i`th
argument, which must be array-valued, using finite differences.
"""
function finite_diff_arr(f::Function, args::Tuple, i::Int, idx, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][idx] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][idx] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Returns the partial derivatives of `f` with respect to all entries of
`args[i]`.

That is, returns an array of the same shape as `args[i]`, each entry of which
is [`finite_diff_arr`](@ref) applied to the corresponding entry of `args[i]`.

Requires that `args[i]` have nonzero rank.  Due to [1], handling
zero-dimensional arrays properly in this function is not feasible; the caller
should handle that case on their own.

[1] https://github.com/JuliaLang/julia/issues/28866
"""
function finite_diff_arr_fullarg(f::Function, args::Tuple, i::Int, dx::Float64)
    @assert args[i] isa AbstractArray
    @assert ndims(args[i]) > 0
    return [finite_diff_arr(f, args, i, idx, dx)
            for idx in keys(args[i])]
end

const dx = 1e-6

# y ~ @gaussian_noise_around x
macro gaussian_noise_around(x)
    :(normal($(esc(x)), 1.0))
end

# y = @traced_gaussian_noise_around(x, :y)
macro traced_gaussian_noise_around(x, y)
    :(
        Gen.@trace(
            normal( $(esc(x)) , 1.0),
            $y
        )
    )
end

# @add_gaussian_noise x y  # means y ~ normal(x, 1.)
macro add_gaussian_noise(x, y)
    Expr(:call, esc(:~), esc(y), :(normal($(esc(x)), 1.0)))
    #:($(esc(y)) $(esc(:~)) normal($(esc(x)), 1.0))
end

macro set_x_to_normal_tilde(mean)
    Expr(:call, esc(:~), esc(:x), :(normal($(esc(mean)), 1)))
    #:($(esc(:x)) $(esc(:~)) normal($(esc(mean)), 1))
end

macro set_x_to_normal_trace(mean)
    :($(esc(:x)) = Gen.@trace(normal($(esc(mean)), 1), $(QuoteNode(:x))))
end

macro set_x_to_normal_traceexpr(mean)
    :($(esc(:x)) = $(Expr(:gentrace,
        :(normal($(esc(mean)), 1.)),
        QuoteNode(:x)
    )))
end

@testset "macros in dynamic DSL" begin
    @gen function foo1()
        x ~ exponential(1)
        y ~ @gaussian_noise_around x # y ~ normal(x, 1)
    end
    trace = simulate(foo1, ())
    @test trace[:y] != trace[:x]

    @gen function foo2()
        x ~ exponential(1)
        y = Gen.@trace(@gaussian_noise_around(x), :y) # y = @trace(normal(x, 1), :y)
    end
    trace = simulate(foo2, ())
    @test trace[:y] != trace[:x]

    @gen function foo3()
        x ~ exponential(1)
        y = @traced_gaussian_noise_around x :y # y = @trace(normal(x, 1), :y)
    end
    trace = simulate(foo3, ())
    @test trace[:y] != trace[:x]

    @gen function foo4()
        x ~ exponential(1)
        @add_gaussian_noise x y # y ~ normal(x, 1)
    end
    trace = simulate(foo4, ())
    @test trace[:y] != trace[:x]

    @gen function foo5()
        y ~ exponential(1)
        @set_x_to_normal_tilde y # x ~ normal(y, 1)
    end
    trace = simulate(foo5, ())
    @test trace[:y] != trace[:x]

    @gen function foo6()
        y ~ exponential(1)
        @set_x_to_normal_trace y # x = Gen.@trace(normal(y, 1), :y)
    end
    trace = simulate(foo6, ())
    @test trace[:y] != trace[:x]

    @gen function foo7()
        y ~ exponential(1)
        @set_x_to_normal_traceexpr y # x = Gen.@trace(normal(y, 1), :y) USING EXPR(:GENTRACE)
    end
    trace = simulate(foo7, ())
    @test trace[:y] != trace[:x]
end

############################################
# Define static functions at global scope: #
############################################

@gen (static) function foo1()
    x ~ exponential(1)
    y ~ @gaussian_noise_around x # y ~ normal(x, 1)
end
@gen (static) function foo2()
    x ~ exponential(1)
    y = Gen.@trace(@gaussian_noise_around(x), :y) # y = @trace(normal(x, 1), :y)
end
@gen (static) function foo3()
    x ~ exponential(1)
    y = @traced_gaussian_noise_around x :y # y = @trace(normal(x, 1), :y)
end
@gen (static) function foo4()
    x ~ exponential(1)
    @add_gaussian_noise x y # y ~ normal(x, 1)
end
@gen (static) function foo5()
    y ~ exponential(1)
    @set_x_to_normal_tilde y # x ~ normal(y, 1)
end
@gen (static) function foo6()
    y ~ exponential(1)
    @set_x_to_normal_trace y # x = Gen.@trace(normal(y, 1), :y)
end
@gen (static) function foo7()
    y ~ exponential(1)
    @set_x_to_normal_traceexpr y # x = Gen.@trace(normal(y, 1), :y) USING EXPR(:GENTRACE)
end

@testset "macros in static DSL" begin
    trace = simulate(foo1, ())
    @test trace[:y] != trace[:x]

    trace = simulate(foo2, ())
    @test trace[:y] != trace[:x]

    trace = simulate(foo3, ())
    @test trace[:y] != trace[:x]

    trace = simulate(foo4, ())
    @test trace[:y] != trace[:x]

    trace = simulate(foo5, ())
    @test trace[:y] != trace[:x]

    trace = simulate(foo6, ())
    @test trace[:y] != trace[:x]

    trace = simulate(foo7, ())
    @test trace[:y] != trace[:x]
end

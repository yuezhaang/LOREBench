# Injected from runtests.jl
using Gen
using Test
import Random
import Distributions

"""
Compute a numerical partial derivative of `f` with respect to the `i`th
argument using finite differences.

If `broadcast` is `false`, then `args[i]` must be a scalar.

If `broadcast` is `true`, then `args[i]` may be an array.  In that case, `f` is
assumed to be the broadcast of a function whose `i`th argument is a scalar.  In
particular, `f` must still operate independently on each element of `args[i]`.
This condition cannot be checked automatically for arbitrary `f::Function`, so
the caller must guarantee it.
"""
function finite_diff(f::Function, args::Tuple, i::Int, dx::Float64;
                     broadcast=false)
    pos_args = Any[args...]
    neg_args = Any[args...]
    if broadcast
        pos_args[i] = copy(args[i]) .+ dx
        neg_args[i] = copy(args[i]) .- dx
        ans = (f(pos_args...) - f(neg_args...)) ./ (2. * dx)
        # Workaround for
        # https://github.com/probcomp/Gen.jl/pull/433#discussion_r669958584
        if args[i] isa AbstractArray && ndims(args[i]) == 0
            return fill(ans)
        end
        return ans
    else
        pos_args[i] += dx
        neg_args[i] -= dx
        return (f(pos_args...) - f(neg_args...)) / (2. * dx)
    end
end

function finite_diff_vec(f::Function, args::Tuple, i::Int, j::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to the `i`th argument, a symettric matrix, using finite differences.

Finite differences are applied symettrically to off-diagonal elements of the matrix, ensuring that the modified matrix is still symettric.

When applied to off-diagonal elements, the finite difference is scaled by a factor of 1/2.

The condition that the `i`th argument is a symettric matrix cannot be checked automatically, so the caller must guarantee it.
"""

function finite_diff_mat_sym(f::Function, args::Tuple, i::Int, j::Int, k::Int, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][j, k] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][j, k] -= dx

    if j!=k
        pos_args[i][k, j] += dx
        neg_args[i][k, j] -= dx
        return (f(pos_args...) - f(neg_args...)) / (4. * dx)
    end

    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Compute a numerical partial derivative of `f` with respect to `idx`th element in the `i`th
argument, which must be array-valued, using finite differences.
"""
function finite_diff_arr(f::Function, args::Tuple, i::Int, idx, dx::Float64)
    pos_args = Any[deepcopy(args)...]
    pos_args[i][idx] += dx
    neg_args = Any[deepcopy(args)...]
    neg_args[i][idx] -= dx
    return (f(pos_args...) - f(neg_args...)) / (2. * dx)
end

"""
Returns the partial derivatives of `f` with respect to all entries of
`args[i]`.

That is, returns an array of the same shape as `args[i]`, each entry of which
is [`finite_diff_arr`](@ref) applied to the corresponding entry of `args[i]`.

Requires that `args[i]` have nonzero rank.  Due to [1], handling
zero-dimensional arrays properly in this function is not feasible; the caller
should handle that case on their own.

[1] https://github.com/JuliaLang/julia/issues/28866
"""
function finite_diff_arr_fullarg(f::Function, args::Tuple, i::Int, dx::Float64)
    @assert args[i] isa AbstractArray
    @assert ndims(args[i]) > 0
    return [finite_diff_arr(f, args, i, idx, dx)
            for idx in keys(args[i])]
end

const dx = 1e-6

@testset "diff arithmetic" begin

    @testset "+" begin
        a = Diffed(1, NoChange())
        b = Diffed(2, NoChange())
        @test get_diff(a + b) == NoChange()
        @test strip_diff(a + b) == 3

        a = 1
        b = Diffed(2, NoChange())
        @test get_diff(a + b) == NoChange()
        @test strip_diff(a + b) == 3

        a = Diffed(1, NoChange())
        b = 2
        @test get_diff(a + b) == NoChange()
        @test strip_diff(a + b) == 3

        a = Diffed(1, UnknownChange())
        b = Diffed(2, UnknownChange())
        @test get_diff(a + b) == UnknownChange()
        @test strip_diff(a + b) == 3

        a = 1
        b = Diffed(2, UnknownChange())
        @test get_diff(a + b) == UnknownChange()
        @test strip_diff(a + b) == 3

        a = Diffed(1, UnknownChange())
        b = 2
        @test get_diff(a + b) == UnknownChange()
        @test strip_diff(a + b) == 3
    end

    # TODO test other binary operators
end

@testset "diff vectors" begin

    @testset "length" begin

    v = Diffed([1, 2, 3], NoChange())
    @test strip_diff(length(v)) == 3
    @test get_diff(length(v)) == NoChange()

    v = Diffed([1, 2, 3], UnknownChange())
    @test strip_diff(length(v)) == 3
    @test get_diff(length(v)) == UnknownChange()

    v = Diffed([1, 2, 3], VectorDiff(3, 4, Dict{Int,Diff}()))
    @test strip_diff(length(v)) == 3
    @test get_diff(length(v)) == IntDiff(-1)

    end

    @testset "getindex" begin

    v = [1, 2, 3]
    i = Diffed(2, UnknownChange())
    @test strip_diff(v[i]) == 2
    @test get_diff(v[i]) == UnknownChange()

    v = [1, 2, 3]
    i = Diffed(2, NoChange())
    @test strip_diff(v[i]) == 2
    @test get_diff(v[i]) == NoChange()

    v = [1, 2, 3]
    i = Diffed(2, IntDiff(1))
    @test strip_diff(v[i]) == 2
    @test get_diff(v[i]) == UnknownChange()

    v = Diffed([1, 2, 3], NoChange())
    @test strip_diff(v[2]) == 2
    @test get_diff(v[2]) == NoChange()

    v = Diffed([1, 2, 3], UnknownChange())
    @test strip_diff(v[2]) == 2
    @test get_diff(v[2]) == UnknownChange()

    # the value at v[2] was not changed
    v = Diffed([1, 2, 3], VectorDiff(3, 4, Dict{Int,Diff}()))
    @test strip_diff(v[2]) == 2
    @test get_diff(v[2]) == NoChange()

    # the value at v[2] was updated (reduced by 3)
    element_diff = IntDiff(-3)
    v = Diffed([1, 2, 3], VectorDiff(3, 4, Dict{Int,Diff}(2 => element_diff)))
    @test strip_diff(v[2]) == 2
    @test get_diff(v[2]) == element_diff
    end
end

@testset "diff dictionaries" begin
end

@testset "diff sets" begin
end
